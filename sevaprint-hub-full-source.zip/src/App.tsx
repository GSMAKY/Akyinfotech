import React, { useState } from 'react';
import {
  Order,
  ServiceItem,
  LedgerTransaction,
  User,
  OrderStatus,
} from './types';
import {
  INITIAL_USER,
  INITIAL_SERVICES,
  INITIAL_ORDERS,
  INITIAL_LEDGER,
} from './data/mockData';
import { Navbar } from './components/Navbar';
import { HubLanding } from './components/HubLanding';
import { CscServicesKiosk } from './components/CscServicesKiosk';
import { MobileRepairKiosk } from './components/MobileRepairKiosk';
import { CustomPrintingStudio } from './components/CustomPrintingStudio';
import { CustomerOrderDashboard } from './components/CustomerOrderDashboard';
import { AdminPipelineKanban } from './components/AdminPipelineKanban';
import { AdminServicesCrud } from './components/AdminServicesCrud';
import { AdminCashLedger } from './components/AdminCashLedger';
import { RevenueChart } from './components/RevenueChart';
import { BlueprintView } from './components/BlueprintView';
import { AuthModal } from './components/AuthModal';
import { InvoiceModal } from './components/InvoiceModal';
import {
  LayoutDashboard,
  Settings,
  BookOpen,
  Receipt,
  Layers,
  ArrowRight,
  ShieldCheck,
  CheckCircle2,
  TrendingUp,
} from 'lucide-react';

export default function App() {
  const [activeView, setActiveView] = useState<
    'home' | 'csc' | 'mobile' | 'printing' | 'orders' | 'admin' | 'blueprint'
  >('home');
  const [isAdminMode, setIsAdminMode] = useState<boolean>(false);
  const [adminSubTab, setAdminSubTab] = useState<'pipeline' | 'services' | 'ledger' | 'analytics'>('pipeline');

  // Core Data States
  const [currentUser, setCurrentUser] = useState<User>(INITIAL_USER);
  const [services, setServices] = useState<ServiceItem[]>(INITIAL_SERVICES);
  const [orders, setOrders] = useState<Order[]>(INITIAL_ORDERS);
  const [ledger, setLedger] = useState<LedgerTransaction[]>(INITIAL_LEDGER);

  // Modals
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [invoiceOrder, setInvoiceOrder] = useState<Order | null>(null);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3500);
  };

  // Pending Approvals Counter
  const pendingApprovalsCount = orders.filter(
    (o) => o.orderStatus === 'awaiting_approval' && !o.customerDesignApproval.isApproved
  ).length;

  // Order Handlers
  const handleOrderCreated = (newOrder: Order) => {
    setOrders((prev) => [newOrder, ...prev]);

    // Record advance payment in cash ledger if advance was paid
    if (newOrder.advancePaid > 0) {
      const newTx: LedgerTransaction = {
        id: 'tx_' + Date.now(),
        orderId: newOrder.orderId,
        category: newOrder.category,
        customerName: newOrder.customerName,
        type: newOrder.balanceRemaining === 0 ? 'direct_payment' : 'advance',
        amount: newOrder.advancePaid,
        paymentMethod: 'UPI / PhonePe',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        notes: `Initial advance for ${newOrder.productType}`,
      };
      setLedger((prev) => [newTx, ...prev]);
    }

    showToast(`Order ${newOrder.orderId} created successfully!`);
  };

  const handleApproveDesign = (orderId: string, legalConsent: string) => {
    setOrders((prev) =>
      prev.map((o) => {
        if (o.id === orderId) {
          const updatedApproval = {
            isApproved: true,
            approvedAt: new Date().toISOString(),
            legalConsentText: legalConsent,
            reviewedByCustomerName: currentUser.name,
            customerIp: '192.168.1.104',
          };

          const newTimelineEvent = {
            status: 'advance_paid' as OrderStatus,
            label: 'Design Legally Approved by Customer',
            timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
            actor: 'customer' as const,
            note: 'Proof inspected & confirmed. Production unlocked.',
          };

          return {
            ...o,
            customerDesignApproval: updatedApproval,
            orderStatus: 'advance_paid',
            timeline: [...o.timeline, newTimelineEvent],
          };
        }
        return o;
      })
    );

    showToast('Design approved! Order unlocked for physical printing.');
  };

  const handleCancelOrder = (orderId: string, reason: string) => {
    const targetOrder = orders.find((o) => o.id === orderId);
    if (!targetOrder) return;

    if (!targetOrder.canCancel || targetOrder.orderStatus !== 'order_received') {
      alert('Order cannot be cancelled: Production processing has already begun.');
      return;
    }

    // Process refund
    const refundAmount = targetOrder.advancePaid;
    if (refundAmount > 0) {
      setCurrentUser((prev) => ({
        ...prev,
        walletBalance: prev.walletBalance + refundAmount,
      }));

      // Record refund in ledger
      const refundTx: LedgerTransaction = {
        id: 'tx_rf_' + Date.now(),
        orderId: targetOrder.orderId,
        category: targetOrder.category,
        customerName: targetOrder.customerName,
        type: 'refund',
        amount: refundAmount,
        paymentMethod: 'Wallet Credit',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        notes: `Instant refund credited to wallet: ${reason}`,
      };
      setLedger((prev) => [refundTx, ...prev]);
    }

    setOrders((prev) =>
      prev.map((o) => {
        if (o.id === orderId) {
          return {
            ...o,
            orderStatus: 'cancelled',
            canCancel: false,
            refundStatus: 'completed',
            timeline: [
              ...o.timeline,
              {
                status: 'cancelled',
                label: 'Order Cancelled by Customer (Accidental Purchase Guarantee)',
                timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
                actor: 'customer',
                note: `Reason: ${reason}. Refund of ₹${refundAmount} credited to wallet.`,
              },
            ],
          };
        }
        return o;
      })
    );

    showToast(`Order cancelled. ₹${refundAmount} instantly refunded to your wallet!`);
  };

  // Admin Order Status Update
  const handleUpdateOrderStatus = (
    orderId: string,
    newStatus: OrderStatus,
    adminProofUrl?: string,
    note?: string
  ) => {
    setOrders((prev) =>
      prev.map((o) => {
        if (o.id === orderId) {
          const isNowPastReceived = newStatus !== 'order_received';
          return {
            ...o,
            orderStatus: newStatus,
            adminDesignProofUrl: adminProofUrl || o.adminDesignProofUrl,
            canCancel: isNowPastReceived ? false : o.canCancel,
            timeline: [
              ...o.timeline,
              {
                status: newStatus,
                label: `Stage changed to ${newStatus.replace('_', ' ')}`,
                timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
                actor: 'admin',
                note: note || undefined,
              },
            ],
          };
        }
        return o;
      })
    );

    showToast(`Order updated to ${newStatus.replace('_', ' ')}`);
  };

  // Services CRUD
  const handleAddService = (newService: ServiceItem) => {
    setServices((prev) => [newService, ...prev]);
    showToast(`Service "${newService.title}" added to live catalog!`);
  };

  const handleUpdateService = (updated: ServiceItem) => {
    setServices((prev) => prev.map((s) => (s.id === updated.id ? updated : s)));
    showToast(`Updated "${updated.title}"`);
  };

  const handleDeleteService = (serviceId: string) => {
    setServices((prev) => prev.filter((s) => s.id !== serviceId));
    showToast('Service removed from catalog.');
  };

  // Ledger Add Transaction
  const handleAddLedgerTx = (tx: LedgerTransaction) => {
    setLedger((prev) => [tx, ...prev]);
    showToast(`Payment of ₹${tx.amount} recorded in accounting ledger.`);
  };

  const handleToggleAdminMode = () => {
    if (!isAdminMode) {
      setIsAdminMode(true);
      setActiveView('admin');
      showToast('Switched to Business Owner Admin Console');
    } else {
      setIsAdminMode(false);
      setActiveView('home');
      showToast('Switched to Customer Interface');
    }
  };

  return (
    <div className="min-h-screen bg-slate-50/50 flex flex-col text-slate-900 selection:bg-slate-900 selection:text-white">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-50 bg-slate-900 text-white px-4 py-2.5 rounded-lg shadow-xl text-xs font-semibold flex items-center gap-2 border border-slate-700 animate-in fade-in slide-in-from-bottom-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Primary Top Bar */}
      <Navbar
        activeView={activeView}
        onNavigate={(v) => {
          if (v === 'admin') {
            setIsAdminMode(true);
          }
          setActiveView(v);
        }}
        currentUser={currentUser}
        isAdminMode={isAdminMode}
        onToggleAdmin={handleToggleAdminMode}
        onOpenAuth={() => setIsAuthModalOpen(true)}
        pendingApprovalsCount={pendingApprovalsCount}
      />

      {/* Admin Subheader Bar (when in Admin mode) */}
      {isAdminMode && (
        <div className="bg-white border-b border-slate-200 px-4 sm:px-6 py-2.5">
          <div className="max-w-7xl mx-auto flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div className="flex items-center gap-2 text-xs">
              <span className="font-bold text-slate-900">Admin Control Center</span>
              <span className="text-slate-400">/</span>
              <span className="text-slate-500 capitalize">{adminSubTab}</span>
            </div>

            <div className="flex items-center gap-1.5 bg-slate-100 p-1 rounded-lg">
              <button
                onClick={() => setAdminSubTab('pipeline')}
                className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors cursor-pointer flex items-center gap-1.5 ${
                  adminSubTab === 'pipeline'
                    ? 'bg-white text-slate-900 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <LayoutDashboard className="w-3.5 h-3.5" />
                <span>8-Stage Workflow Pipeline</span>
              </button>
              <button
                onClick={() => setAdminSubTab('services')}
                className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors cursor-pointer flex items-center gap-1.5 ${
                  adminSubTab === 'services'
                    ? 'bg-white text-slate-900 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <Settings className="w-3.5 h-3.5" />
                <span>Services CRUD ({services.length})</span>
              </button>
              <button
                onClick={() => setAdminSubTab('ledger')}
                className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors cursor-pointer flex items-center gap-1.5 ${
                  adminSubTab === 'ledger'
                    ? 'bg-white text-slate-900 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <Receipt className="w-3.5 h-3.5" />
                <span>Cash & Ledger ({ledger.length})</span>
              </button>
              <button
                onClick={() => setAdminSubTab('analytics')}
                className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors cursor-pointer flex items-center gap-1.5 ${
                  adminSubTab === 'analytics'
                    ? 'bg-white text-slate-900 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <TrendingUp className="w-3.5 h-3.5 text-indigo-600" />
                <span>Revenue vs Service</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Main Viewport Content */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 py-8">
        {activeView === 'home' && !isAdminMode && (
          <HubLanding
            onNavigate={(v) => {
              if (v === 'admin') setIsAdminMode(true);
              setActiveView(v);
            }}
            pendingApprovalsCount={pendingApprovalsCount}
          />
        )}

        {activeView === 'csc' && !isAdminMode && (
          <CscServicesKiosk
            services={services}
            currentUser={currentUser}
            onOrderCreated={handleOrderCreated}
            onNavigateToOrders={() => setActiveView('orders')}
          />
        )}

        {activeView === 'mobile' && !isAdminMode && (
          <MobileRepairKiosk
            services={services}
            currentUser={currentUser}
            onOrderCreated={handleOrderCreated}
            onNavigateToOrders={() => setActiveView('orders')}
          />
        )}

        {activeView === 'printing' && !isAdminMode && (
          <CustomPrintingStudio
            services={services}
            currentUser={currentUser}
            onOrderCreated={handleOrderCreated}
            onNavigateToOrders={() => setActiveView('orders')}
          />
        )}

        {activeView === 'orders' && !isAdminMode && (
          <CustomerOrderDashboard
            orders={orders}
            currentUser={currentUser}
            onApproveDesign={handleApproveDesign}
            onCancelOrder={handleCancelOrder}
            onViewInvoice={(ord) => setInvoiceOrder(ord)}
            onNavigateToStudio={() => setActiveView('printing')}
          />
        )}

        {activeView === 'blueprint' && (
          <BlueprintView />
        )}

        {/* Admin Views */}
        {isAdminMode && (
          <div className="space-y-6">
            {adminSubTab === 'pipeline' && (
              <AdminPipelineKanban
                orders={orders}
                onUpdateOrderStatus={handleUpdateOrderStatus}
                onRecordPayment={handleAddLedgerTx}
                onViewInvoice={(ord) => setInvoiceOrder(ord)}
              />
            )}

            {adminSubTab === 'services' && (
              <AdminServicesCrud
                services={services}
                onAddService={handleAddService}
                onUpdateService={handleUpdateService}
                onDeleteService={handleDeleteService}
              />
            )}

            {adminSubTab === 'ledger' && (
              <AdminCashLedger
                transactions={ledger}
                orders={orders}
                onAddTransaction={handleAddLedgerTx}
              />
            )}

            {adminSubTab === 'analytics' && (
              <RevenueChart
                orders={orders}
                transactions={ledger}
              />
            )}
          </div>
        )}
      </main>

      {/* Footer */}
      <footer className="border-t border-slate-200 bg-white py-8 px-4 sm:px-6 mt-12 text-xs text-slate-500">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <span className="font-bold text-slate-900">SevaPrint Hub</span>
            <span>·</span>
            <span>CSC Digital Seva Kendra</span>
            <span>·</span>
            <span>Mobile Repair Lab</span>
            <span>·</span>
            <span>Custom Printing Studio</span>
          </div>

          <div className="flex items-center gap-4">
            <button
              onClick={() => { setIsAdminMode(false); setActiveView('blueprint'); }}
              className="hover:text-slate-900 transition-colors cursor-pointer"
            >
              Architecture Blueprint & SQL Schema
            </button>
            <span>·</span>
            <span className="flex items-center gap-1 text-emerald-700">
              <ShieldCheck className="w-3.5 h-3.5" />
              DPDPA 2023 Secure
            </span>
          </div>
        </div>
      </footer>

      {/* Authentication Modal */}
      <AuthModal
        isOpen={isAuthModalOpen}
        onClose={() => setIsAuthModalOpen(false)}
        currentUser={currentUser}
        onLoginSuccess={(u) => {
          setCurrentUser(u);
          showToast(`Welcome back, ${u.name}!`);
        }}
      />

      {/* Printable Invoice Modal */}
      <InvoiceModal
        order={invoiceOrder}
        onClose={() => setInvoiceOrder(null)}
      />
    </div>
  );
}
