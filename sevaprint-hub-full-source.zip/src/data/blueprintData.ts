export const BLUEPRINT_DATA = {
  overview: {
    title: "SevaPrint 3-in-1 Business Portal Architecture & Blueprint",
    subtitle: "Enterprise Blueprint for Unified CSC Digital Services, Mobile Repair, and Custom Printing Hub",
    version: "2.4.0-Production",
    architect: "Principal Software Architect & Full-Stack Lead",
    lastUpdated: "October 2026",
    summary: "A robust, multi-tenant capable architecture engineered around an irreversible 8-stage operational pipeline, legal customer design approval gates, pre-flight accidental cancellation protections, end-to-end encryption for government documents, and unified cash ledger accounting across physical counter & online operations."
  },

  techStack: [
    {
      category: "Frontend Framework & UI",
      technology: "Next.js 15 (App Router) + React 19 + Tailwind CSS v4",
      rationale: "Zero-bundle server components for fast initial load in low-bandwidth rural/semi-urban network regions; dynamic client-side canvas customizer for printing studio; instant responsive rendering."
    },
    {
      category: "Primary Database & ORM",
      technology: "PostgreSQL 16 on Supabase or AWS RDS + Prisma / Drizzle ORM",
      rationale: "Strict relational ACID compliance needed for sequence-safe unique Order ID generation, double-entry cash ledger, foreign key constraints, and transactional consistency during stage transitions."
    },
    {
      category: "Blob Storage & Document Vault",
      technology: "Cloudflare R2 / AWS S3 + Server-Side KMS Encryption",
      rationale: "Zero-egress fee object storage. Government ID scans and customer artwork stored with AES-256-GCM encryption. Customer downloads authenticated via 15-minute time-to-live (TTL) presigned URLs."
    },
    {
      category: "Authentication & SMS OTP",
      technology: "NextAuth.js v5 / Supabase Auth + Fast2SMS / MSG91 / Twilio Gateway",
      rationale: "Seamless phone-number login with 6-digit OTP verification customized for Indian mobile format (+91), alongside Google / Email authentication."
    },
    {
      category: "Payment Gateway",
      technology: "Razorpay / Cashfree / UPI Dynamic QR Integration",
      rationale: "Instant UPI intent links, QR code generation at the shop counter, split settlement for advance (40-50%) and balance on pickup/delivery."
    },
    {
      category: "Async Background Worker",
      technology: "BullMQ / Redis + Upstash Serverless Redis",
      rationale: "Handles automated refund executions upon eligible accidental cancellations, image thumbnail generation, automated SMS/WhatsApp order status notifications."
    }
  ],

  dbSchemaSql: `-- =====================================================================
-- POSTGRESQL RELATIONAL SCHEMA: 3-IN-1 BUSINESS PORTAL (SEVAPRINT HUB)
-- Version: 2.4 | Compatible with PostgreSQL 14+, Supabase, AWS RDS
-- =====================================================================

-- 1. EXTENSIONS & ENUMS
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

CREATE TYPE product_category_enum AS ENUM ('printing', 'mobile', 'csc');
CREATE TYPE order_status_enum AS ENUM (
  'order_received',
  'designing',
  'awaiting_approval',
  'advance_paid',
  'printing',
  'quality_check',
  'packing',
  'ready_delivery',
  'cancelled'
);
CREATE TYPE payment_type_enum AS ENUM ('advance', 'balance', 'refund', 'full');
CREATE TYPE payment_mode_enum AS ENUM ('upi', 'cash', 'card', 'wallet');

-- 2. SEQUENCE FOR FORMATTED UNIQUE ORDER ID (e.g. ORD-2026-001042)
CREATE SEQUENCE IF NOT EXISTS order_id_seq START 1001;

CREATE OR REPLACE FUNCTION generate_order_code()
RETURNS TRIGGER AS $$
BEGIN
  IF NEW.order_code IS NULL OR NEW.order_code = '' THEN
    NEW.order_code := 'ORD-' || TO_CHAR(CURRENT_DATE, 'YYYY') || '-' || LPAD(NEXTVAL('order_id_seq')::TEXT, 6, '0');
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- 3. USERS & PROFILES TABLE
CREATE TABLE users (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  phone_number VARCHAR(15) UNIQUE NOT NULL,
  email VARCHAR(255) UNIQUE,
  full_name VARCHAR(120) NOT NULL,
  role VARCHAR(20) DEFAULT 'customer' CHECK (role IN ('customer', 'operator', 'designer', 'admin')),
  wallet_balance NUMERIC(12, 2) DEFAULT 0.00 CHECK (wallet_balance >= 0),
  is_verified BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

-- 4. SERVICES CATALOG (DYNAMIC CRUD BY ADMIN)
CREATE TABLE services_catalog (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  category product_category_enum NOT NULL,
  title VARCHAR(150) NOT NULL,
  slug VARCHAR(150) UNIQUE NOT NULL,
  description TEXT,
  base_price NUMERIC(10, 2) NOT NULL CHECK (base_price >= 0),
  turnaround_hours INT DEFAULT 24,
  is_active BOOLEAN DEFAULT TRUE,
  required_docs JSONB DEFAULT '[]'::JSONB,
  configuration_options JSONB DEFAULT '{}'::JSONB,
  created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

-- 5. ORDERS TABLE (CENTRAL LIFECYCLE CONTROLLER)
CREATE TABLE orders (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  order_code VARCHAR(32) UNIQUE NOT NULL,
  user_id UUID REFERENCES users(id) ON DELETE SET NULL,
  customer_name VARCHAR(120) NOT NULL,
  customer_phone VARCHAR(15) NOT NULL,
  customer_email VARCHAR(255),
  category product_category_enum NOT NULL,
  service_id UUID REFERENCES services_catalog(id) ON DELETE RESTRICT,
  product_type VARCHAR(150) NOT NULL,
  quantity INT NOT NULL DEFAULT 1 CHECK (quantity > 0),
  
  -- Financial Fields
  total_price NUMERIC(10, 2) NOT NULL CHECK (total_price >= 0),
  advance_paid NUMERIC(10, 2) DEFAULT 0.00 CHECK (advance_paid >= 0),
  balance_remaining NUMERIC(10, 2) GENERATED ALWAYS AS (total_price - advance_paid) STORED,
  
  -- Design Proof & Customer Legal Approval Gate
  customer_design_file_url TEXT,
  admin_design_proof_url TEXT,
  design_approved BOOLEAN DEFAULT FALSE,
  design_approved_at TIMESTAMPTZ,
  design_approval_ip INET,
  design_approval_consent_hash TEXT, -- Cryptographic hash of accepted terms
  
  -- Workflow & Operational Stage
  status order_status_enum NOT NULL DEFAULT 'order_received',
  is_qc_passed BOOLEAN DEFAULT FALSE,
  qc_inspector_notes TEXT,
  
  -- Accidental Cancellation Gate (Immutable flag)
  cancellation_allowed BOOLEAN DEFAULT TRUE,
  cancelled_at TIMESTAMPTZ,
  cancellation_reason TEXT,
  refund_status VARCHAR(20) DEFAULT 'none' CHECK (refund_status IN ('none', 'initiated', 'completed')),
  
  -- Service Specific Payloads
  customization_payload JSONB DEFAULT '{}'::JSONB,
  encrypted_document_metadata JSONB DEFAULT '[]'::JSONB,
  
  delivery_date DATE,
  created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

-- Attach Order Code Generator Trigger
CREATE TRIGGER trigger_generate_order_code
BEFORE INSERT ON orders
FOR EACH ROW
EXECUTE FUNCTION generate_order_code();

-- 6. ORDER AUDIT & WORKFLOW TIMELINE
CREATE TABLE order_timeline (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  order_id UUID NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
  status order_status_enum NOT NULL,
  actor_role VARCHAR(20) NOT NULL,
  actor_id UUID REFERENCES users(id),
  action_summary VARCHAR(255) NOT NULL,
  internal_notes TEXT,
  created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

-- 7. DOUBLE-ENTRY CASH & ACCOUNTING LEDGER
CREATE TABLE accounting_ledger (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  order_id UUID NOT NULL REFERENCES orders(id) ON DELETE RESTRICT,
  category product_category_enum NOT NULL,
  transaction_type payment_type_enum NOT NULL,
  amount NUMERIC(10, 2) NOT NULL CHECK (amount > 0),
  payment_mode payment_mode_enum NOT NULL,
  reference_txn_id VARCHAR(100),
  recorded_by UUID REFERENCES users(id),
  created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

-- 8. INDEXES FOR HIGH-THROUGHPUT QUERIES
CREATE INDEX idx_orders_customer_phone ON orders(customer_phone);
CREATE INDEX idx_orders_status ON orders(status);
CREATE INDEX idx_orders_category ON orders(category);
CREATE INDEX idx_orders_created_at ON orders(created_at DESC);
CREATE INDEX idx_ledger_created_at ON accounting_ledger(created_at DESC);
CREATE INDEX idx_ledger_category ON accounting_ledger(category);`,

  apiSpecs: [
    {
      method: "POST",
      endpoint: "/api/v1/auth/otp/send",
      description: "Dispatches a time-limited 6-digit OTP to the customer's Indian phone number (+91). Rate-limited to 3 requests per 10 minutes per IP.",
      auth: "Public",
      requestPayload: `{ "phone": "9876543210" }`,
      responsePayload: `{ "success": true, "sessionToken": "jwt_temp_auth_token", "expiresIn": 300 }`
    },
    {
      method: "POST",
      endpoint: "/api/v1/orders/create",
      description: "Generates a new order with auto-assigned Order ID. Status initializes at 'order_received'. Accidental cancellation flag 'cancellation_allowed' is strictly set to TRUE.",
      auth: "Customer or Anonymous Session",
      requestPayload: `{
  "category": "printing",
  "serviceId": "7f8b9c-...",
  "productType": "Custom Bio-Washed T-Shirt",
  "quantity": 2,
  "customization": { "size": "L", "color": "#1e293b", "text": "Tech Conclave 2026" },
  "customerDesignUrl": "https://vault.sevaprint.com/uploads/raw-art-892.png",
  "totalPrice": 798.00,
  "advancePaid": 300.00,
  "paymentMethod": "UPI / PhonePe"
}`,
      responsePayload: `{
  "orderId": "ORD-2026-001042",
  "status": "order_received",
  "cancellationAllowed": true,
  "advanceReceived": 300.00,
  "balanceDue": 498.00
}`
    },
    {
      method: "POST",
      endpoint: "/api/v1/orders/:orderId/cancel",
      description: "ACCIDENTAL PURCHASE SAFETY GUARD. Strictly validates that order.status is still 'order_received'. If admin has shifted to 'designing' or 'awaiting_approval', the request returns 409 Conflict. If valid, instantly credits the customer wallet/initiates gateway refund.",
      auth: "Order Owner",
      requestPayload: `{ "cancellationReason": "Accidental quantity mistake" }`,
      responsePayload: `{
  "orderId": "ORD-2026-001042",
  "status": "cancelled",
  "refundInitiated": true,
  "refundAmount": 300.00,
  "creditedTo": "customer_wallet_or_source_upi"
}`
    },
    {
      method: "POST",
      endpoint: "/api/v1/orders/:orderId/design-proof",
      description: "Admin/Designer uploads high-resolution production-ready proof with bleed/trim margins and shifts order status to 'awaiting_approval'. This automatically locks the accidental cancellation window.",
      auth: "Role: Designer / Admin",
      requestPayload: `{
  "proofUrl": "https://vault.sevaprint.com/proofs/proof-ORD-2026-001042-v1.pdf",
  "notes": "Colors calibrated for CMYK 300DPI sublimation."
}`,
      responsePayload: `{
  "orderId": "ORD-2026-001042",
  "status": "awaiting_approval",
  "cancellationAllowed": false
}`
    },
    {
      method: "POST",
      endpoint: "/api/v1/orders/:orderId/approve-design",
      description: "CUSTOMER DESIGN APPROVAL GATE. Mandatory legal sign-off. Customer verifies spellings, colors, text, and dimensions. Printing step CANNOT be executed until this endpoint writes the approval record with timestamp and consent hash.",
      auth: "Customer Only",
      requestPayload: `{
  "legalConsentAgreed": true,
  "consentDeclaration": "I approve this design, text, spelling, and colors for final print.",
  "clientTimestamp": "2026-10-24T12:30:00Z"
}`,
      responsePayload: `{
  "orderId": "ORD-2026-001042",
  "designApproved": true,
  "approvedAt": "2026-10-24T12:30:00.124Z",
  "unlockedNextStage": "advance_paid / printing"
}`
    },
    {
      method: "POST",
      endpoint: "/api/v1/orders/:orderId/advance-stage",
      description: "Admin advances order across operational pipeline. Enforces strict stage invariants (e.g. Stage 5 'Printing' will fail with 412 Precondition Failed if design_approved is FALSE).",
      auth: "Role: Operator / Admin",
      requestPayload: `{
  "targetStage": "printing",
  "qcChecklist": { "dimensionsVerified": true, "colorMatchVerified": true },
  "notes": "Batch printed on Epson SureColor."
}`,
      responsePayload: `{
  "orderId": "ORD-2026-001042",
  "status": "printing",
  "updatedAt": "2026-10-24T14:10:00Z"
}`
    },
    {
      method: "GET",
      endpoint: "/api/v1/admin/ledger/summary",
      description: "Aggregates counter cash, UPI collections, pending balances, and vertical breakdowns (Printing vs Mobile vs CSC) for any chosen date range.",
      auth: "Role: Admin",
      requestPayload: `None (Query params: ?from=2026-10-24&to=2026-10-24&category=all)`,
      responsePayload: `{
  "date": "2026-10-24",
  "totalDailyRevenue": 24850.00,
  "totalAdvanceCollected": 14200.00,
  "outstandingReceivable": 10650.00,
  "byCategory": {
    "printing": { "revenue": 12400.00, "ordersCount": 18 },
    "mobile": { "revenue": 8900.00, "ordersCount": 7 },
    "csc": { "revenue": 3550.00, "ordersCount": 24 }
  }
}`
    }
  ],

  securityArchitecture: {
    cscGovtDocVault: {
      title: "Government Document Vault & Sensitive Citizen Data Protection",
      protocols: [
        {
          layer: "Client-Side Pre-Upload Hash & Envelope Encryption",
          details: "Before Aadhaar, PAN card, or Voter ID scans leave the user's browser, a random 256-bit symmetric data key (DEK) encrypts the file via Web Crypto API (AES-GCM). The DEK is encrypted using the server's public key (KEM) so raw cleartext documents never transit in plain HTTP."
        },
        {
          layer: "Zero-Knowledge Ephemeral Signed URLs (15-min TTL)",
          details: "Direct public access to cloud storage buckets is disabled. Storage buckets are private with block-all-public-access. When an authorized CSC operator views a document to submit a portal form, the server issues a presigned URL expiring strictly in 900 seconds."
        },
        {
          layer: "Automated Ephemeral Retention & Purging Policy",
          details: "To comply with India's Digital Personal Data Protection Act (DPDPA 2023) and Aadhaar Regulations, identity document files are scheduled for automatic hard deletion 14 days after the CSC service order is fulfilled."
        },
        {
          layer: "Operator Access Watermarking",
          details: "When an operator opens a customer's document scan, a dynamic SVG overlay watermarks the screen with the Operator ID, IP address, and timestamp to prevent unauthorized screen captures or leakages."
        }
      ]
    },
    mobileCustomerPrivacy: {
      title: "Mobile Repair Customer Privacy Protocol",
      protocols: [
        {
          layer: "No Passcode Retention Policy",
          details: "Technicians conduct hardware functional tests (display touch, camera, mic) in Android/iOS Diagnostic Test Mode (e.g. Apple Diagnostics or Samsung Maintenance Mode / *#0*#) without asking for the customer's lock screen PIN/passcode."
        },
        {
          layer: "IMEI & Serial Number Masking",
          details: "Hardware identifiers are tokenized in the customer-facing views (e.g. IMEI 8649********21) to prevent device spoofing or unauthorized lookup."
        }
      ]
    }
  },

  operationalWorkflowRules: [
    {
      step: 1,
      name: "Order Received",
      actor: "Customer / Counter Operator",
      cancellationActive: true,
      description: "Order entry created with customer details, selected service, custom requirements, and initial advance quote. Accidental cancellation window is open."
    },
    {
      step: 2,
      name: "Designing / Processing",
      actor: "Shop Designer / Technician",
      cancellationActive: false,
      description: "Staff initiates design drafting or opens mobile hardware diagnostic. Accidental cancellation window is LOCKED once production hours commence."
    },
    {
      step: 3,
      name: "Awaiting Customer Approval",
      actor: "Designer & Customer",
      cancellationActive: false,
      description: "Designer uploads high-res proof. System sends SMS/WhatsApp alert with approval link. Order halts until customer explicitly clicks the Legal Approval Gate."
    },
    {
      step: 4,
      name: "Advance Paid / Verified",
      actor: "Customer & Cashier",
      cancellationActive: false,
      description: "Customer verifies proof and completes advance payment (minimum 40% or full). Cash ledger registers the transaction."
    },
    {
      step: 5,
      name: "Printing / Hardware Servicing",
      actor: "Print Operator / Hardware Tech",
      cancellationActive: false,
      description: "Physical sublimation printing, screen replacement, or official government portal certificate processing commences."
    },
    {
      step: 6,
      name: "Quality Check (QC)",
      actor: "Lead Quality Supervisor",
      cancellationActive: false,
      description: "Rigorous checklist inspection: color fidelity, print alignment, screen touch calibration, certificate accuracy."
    },
    {
      step: 7,
      name: "Packing & Invoicing",
      actor: "Packaging Staff",
      cancellationActive: false,
      description: "Sealed packaging with printed invoice, barcode label, warranty card, and pickup notification dispatch."
    },
    {
      step: 8,
      name: "Ready for Delivery / Delivered",
      actor: "Customer & Store Delivery",
      cancellationActive: false,
      description: "Customer collects item at counter or delivery partner hands over package. Balance amount collected and recorded in daily cash ledger."
    }
  ]
};
