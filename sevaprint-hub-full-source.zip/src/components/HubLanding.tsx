import React from 'react';
import { ASSET_PATHS } from '../data/mockData';
import {
  FileText,
  Wrench,
  Printer,
  ShieldCheck,
  CheckCircle2,
  Clock,
  ArrowRight,
  Sparkles,
  Lock,
  Layers,
} from 'lucide-react';

interface HubLandingProps {
  onNavigate: (view: 'csc' | 'mobile' | 'printing' | 'orders' | 'admin' | 'blueprint') => void;
  pendingApprovalsCount: number;
}

export const HubLanding: React.FC<HubLandingProps> = ({
  onNavigate,
  pendingApprovalsCount,
}) => {
  return (
    <div className="space-y-12">
      {/* Hero Section */}
      <div className="bg-white border border-slate-200 rounded-2xl p-6 sm:p-10 space-y-6">
        <div className="flex flex-wrap items-center gap-3 text-xs text-slate-500">
          <span className="font-semibold text-slate-800">SevaPrint Multi-Vertical Hub</span>
          <span aria-hidden="true">·</span>
          <span>Integrated 3-in-1 Platform</span>
          <span aria-hidden="true">·</span>
          <span>Governed 8-Stage Lifecycle</span>
        </div>

        <div className="max-w-3xl space-y-4">
          <h1 className="text-3xl sm:text-4xl lg:text-5xl font-bold tracking-tight text-slate-900 leading-tight">
            Digital Citizen Services, Mobile Repair & Custom Printing Studio
          </h1>
          <p className="text-sm sm:text-base text-slate-600 leading-relaxed">
            One unified portal for government e-forms and certificate filing, precision smartphone hardware diagnostics, and on-demand custom sublimation merchandise. Built with a mandatory customer design approval gate and accidental order cancellation protection.
          </p>
        </div>

        <div className="flex flex-wrap gap-3 pt-2">
          <button
            onClick={() => onNavigate('printing')}
            className="px-5 py-2.5 text-xs font-bold text-white bg-slate-900 hover:bg-slate-800 rounded-lg transition-colors flex items-center gap-2 cursor-pointer"
          >
            <Printer className="w-4 h-4" />
            <span>Launch Print Studio</span>
          </button>
          <button
            onClick={() => onNavigate('mobile')}
            className="px-5 py-2.5 text-xs font-semibold text-slate-800 bg-slate-100 hover:bg-slate-200 border border-slate-200 rounded-lg transition-colors flex items-center gap-2 cursor-pointer"
          >
            <Wrench className="w-4 h-4 text-slate-600" />
            <span>Book Mobile Repair</span>
          </button>
          <button
            onClick={() => onNavigate('csc')}
            className="px-5 py-2.5 text-xs font-semibold text-slate-800 bg-slate-100 hover:bg-slate-200 border border-slate-200 rounded-lg transition-colors flex items-center gap-2 cursor-pointer"
          >
            <FileText className="w-4 h-4 text-slate-600" />
            <span>CSC Digital Seva</span>
          </button>
          <button
            onClick={() => onNavigate('blueprint')}
            className="px-5 py-2.5 text-xs font-semibold text-indigo-700 bg-indigo-50 hover:bg-indigo-100 border border-indigo-200 rounded-lg transition-colors flex items-center gap-2 cursor-pointer"
          >
            <Layers className="w-4 h-4" />
            <span>View Architecture Blueprint</span>
          </button>
        </div>
      </div>

      {/* 3 Core Business Verticals Grid */}
      <div>
        <div className="mb-6">
          <h2 className="text-lg font-bold text-slate-900">Explore Our 3 Core Service Centers</h2>
          <p className="text-xs text-slate-500">
            Dedicated customer kiosks with real-time quotations and secure submission
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Vertical 1: Custom Printing */}
          <div className="bg-white rounded-xl border border-slate-200 overflow-hidden flex flex-col justify-between hover:border-slate-400 transition-colors group">
            <div className="h-48 overflow-hidden relative">
              <img
                src={ASSET_PATHS.printingStudio}
                alt="Custom Printing Studio"
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                referrerPolicy="no-referrer"
              />
              <div className="absolute top-3 left-3 bg-white/90 backdrop-blur-xs text-slate-900 px-2.5 py-1 rounded text-[11px] font-bold">
                Merchandise & Sublimation
              </div>
            </div>
            <div className="p-5 flex-1 flex flex-col justify-between space-y-4">
              <div className="space-y-2">
                <h3 className="text-base font-bold text-slate-900">
                  Custom Printing Studio
                </h3>
                <p className="text-xs text-slate-600 leading-relaxed">
                  Design custom T-shirts (220 GSM bio-washed), ceramic mugs, silent wall clocks, and totes with live mockup rendering.
                </p>
                <div className="pt-2 text-[11px] text-slate-500 space-y-1">
                  <div>· Pre-Press Color Calibration</div>
                  <div>· Mandatory Customer Legal Proof Sign-off</div>
                  <div>· Volume Quantity Discounts (up to 25% off)</div>
                </div>
              </div>

              <button
                onClick={() => onNavigate('printing')}
                className="w-full py-2 px-3 text-xs font-semibold text-white bg-slate-900 rounded-lg hover:bg-slate-800 transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
              >
                <span>Customize Products</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          {/* Vertical 2: Mobile Repairing */}
          <div className="bg-white rounded-xl border border-slate-200 overflow-hidden flex flex-col justify-between hover:border-slate-400 transition-colors group">
            <div className="h-48 overflow-hidden relative">
              <img
                src={ASSET_PATHS.mobileRepair}
                alt="Mobile Repair Workbench"
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                referrerPolicy="no-referrer"
              />
              <div className="absolute top-3 left-3 bg-white/90 backdrop-blur-xs text-slate-900 px-2.5 py-1 rounded text-[11px] font-bold">
                Electronics & Diagnostics
              </div>
            </div>
            <div className="p-5 flex-1 flex flex-col justify-between space-y-4">
              <div className="space-y-2">
                <h3 className="text-base font-bold text-slate-900">
                  Mobile Repairing Kiosk
                </h3>
                <p className="text-xs text-slate-600 leading-relaxed">
                  Certified replacement for broken OLED screens, swollen batteries, water damage ultrasonic recovery, and motherboard micro-soldering.
                </p>
                <div className="pt-2 text-[11px] text-slate-500 space-y-1">
                  <div>· Zero-PIN Required (Diagnostic Mode)</div>
                  <div>· Transparent Live Parts & Labor Quote</div>
                  <div>· Express 2-Hour Bench Turnaround</div>
                </div>
              </div>

              <button
                onClick={() => onNavigate('mobile')}
                className="w-full py-2 px-3 text-xs font-semibold text-white bg-slate-900 rounded-lg hover:bg-slate-800 transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
              >
                <span>Book Diagnostic Slot</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          {/* Vertical 3: CSC Digital Citizen Services */}
          <div className="bg-white rounded-xl border border-slate-200 overflow-hidden flex flex-col justify-between hover:border-slate-400 transition-colors group">
            <div className="h-48 overflow-hidden relative">
              <img
                src={ASSET_PATHS.cscServices}
                alt="CSC Digital Seva Kendra"
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                referrerPolicy="no-referrer"
              />
              <div className="absolute top-3 left-3 bg-white/90 backdrop-blur-xs text-slate-900 px-2.5 py-1 rounded text-[11px] font-bold">
                Government Facilitation
              </div>
            </div>
            <div className="p-5 flex-1 flex flex-col justify-between space-y-4">
              <div className="space-y-2">
                <h3 className="text-base font-bold text-slate-900">
                  CSC / Digital Services Kiosk
                </h3>
                <p className="text-xs text-slate-600 leading-relaxed">
                  Authorized digital assistance for PAN cards (49A), Aadhaar demographic updates, PM-Kisan, passport appointments, and state certificates.
                </p>
                <div className="pt-2 text-[11px] text-slate-500 space-y-1">
                  <div>· Client-Side AES-256 Vault Encryption</div>
                  <div>· 14-Day Ephemeral Retention Compliance</div>
                  <div>· Official Acknowledgement Receipts</div>
                </div>
              </div>

              <button
                onClick={() => onNavigate('csc')}
                className="w-full py-2 px-3 text-xs font-semibold text-white bg-slate-900 rounded-lg hover:bg-slate-800 transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
              >
                <span>Apply for e-Services</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Operational 8-Stage Pipeline Showcase */}
      <div className="bg-white rounded-xl border border-slate-200 p-6 sm:p-8 space-y-6">
        <div className="space-y-1">
          <h2 className="text-lg font-bold text-slate-900">
            The Governed 8-Stage Operational Workflow
          </h2>
          <p className="text-xs text-slate-500">
            Every customer order progresses through strict invariants. Physical printing is strictly locked until Customer Design Approval.
          </p>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-3">
          {[
            { step: '01', title: 'Order Received', desc: 'Accidental cancel window active' },
            { step: '02', title: 'Designing', desc: 'Pre-press artwork & prep' },
            { step: '03', title: 'Design Approval', desc: 'Customer legal sign-off gate' },
            { step: '04', title: 'Advance Paid', desc: 'Deposit posted to ledger' },
            { step: '05', title: 'Printing / Work', desc: 'Sublimation or hardware repair' },
            { step: '06', title: 'Quality Check', desc: 'QC checklist inspection' },
            { step: '07', title: 'Packing', desc: 'Packaged with tax invoice' },
            { step: '08', title: 'Delivery', desc: 'Balance collected & handed over' },
          ].map((st, i) => (
            <div
              key={i}
              className="p-3 bg-slate-50 rounded-lg border border-slate-200 space-y-1 flex flex-col justify-between"
            >
              <div>
                <span className="font-mono text-xs font-bold text-slate-900">{st.step}</span>
                <h4 className="text-xs font-bold text-slate-800 mt-1">{st.title}</h4>
              </div>
              <p className="text-[10px] text-slate-500 leading-normal">{st.desc}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Trust & Security Verification Strip */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="p-4 bg-white rounded-xl border border-slate-200 flex items-start gap-3">
          <ShieldCheck className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
          <div className="space-y-0.5 text-xs">
            <span className="font-bold text-slate-900 block">Accidental Order Guarantee</span>
            <p className="text-slate-600">
              One-click instantaneous refund to digital wallet if cancelled before staff begins designing.
            </p>
          </div>
        </div>

        <div className="p-4 bg-white rounded-xl border border-slate-200 flex items-start gap-3">
          <Lock className="w-5 h-5 text-indigo-600 shrink-0 mt-0.5" />
          <div className="space-y-0.5 text-xs">
            <span className="font-bold text-slate-900 block">DPDPA 2023 Identity Vault</span>
            <p className="text-slate-600">
              Citizen identity scans are encrypted client-side and automatically purged 14 days post-fulfillment.
            </p>
          </div>
        </div>

        <div className="p-4 bg-white rounded-xl border border-slate-200 flex items-start gap-3">
          <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
          <div className="space-y-0.5 text-xs">
            <span className="font-bold text-slate-900 block">Customer Approval Gate</span>
            <p className="text-slate-600">
              Zero printing errors. You visually verify color calibration and typography before production begins.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
