import React, { useState } from 'react';
import { Order, User, OrderStatus } from '../types';
import {
  CheckCircle2,
  AlertTriangle,
  Clock,
  Printer,
  ShieldCheck,
  Eye,
  FileCheck,
  RotateCcw,
  Receipt,
  ArrowRight,
  XCircle,
  ExternalLink,
} from 'lucide-react';

interface CustomerOrderDashboardProps {
  orders: Order[];
  currentUser: User;
  onApproveDesign: (orderId: string, legalConsent: string) => void;
  onCancelOrder: (orderId: string, reason: string) => void;
  onViewInvoice: (order: Order) => void;
  onNavigateToStudio: () => void;
}

export const CustomerOrderDashboard: React.FC<CustomerOrderDashboardProps> = ({
  orders,
  currentUser,
  onApproveDesign,
  onCancelOrder,
  onViewInvoice,
  onNavigateToStudio,
}) => {
  const [selectedProofOrder, setSelectedProofOrder] = useState<Order | null>(null);
  const [legalConsentChecked, setLegalConsentChecked] = useState(false);
  const [cancelModalOrder, setCancelModalOrder] = useState<Order | null>(null);
  const [cancellationReason, setCancellationReason] = useState('Accidental purchase / placed in error');
  const [activeFilter, setActiveFilter] = useState<'all' | 'needs_approval' | 'active' | 'completed'>('all');

  // Filter orders for current user or all mock orders
  const userOrders = orders;

  const pendingApprovalOrders = userOrders.filter(
    (o) => o.orderStatus === 'awaiting_approval' && !o.customerDesignApproval.isApproved
  );

  const filteredOrders = userOrders.filter((o) => {
    if (activeFilter === 'needs_approval') {
      return o.orderStatus === 'awaiting_approval' && !o.customerDesignApproval.isApproved;
    }
    if (activeFilter === 'active') {
      return o.orderStatus !== 'ready_delivery' && o.orderStatus !== 'cancelled';
    }
    if (activeFilter === 'completed') {
      return o.orderStatus === 'ready_delivery' || o.orderStatus === 'cancelled';
    }
    return true;
  });

  const getStatusBadge = (status: OrderStatus) => {
    switch (status) {
      case 'order_received':
        return { label: 'Order Received (Cancellable)', color: 'bg-blue-50 text-blue-700 border-blue-200' };
      case 'designing':
        return { label: 'Designing / Diagnostics', color: 'bg-purple-50 text-purple-700 border-purple-200' };
      case 'awaiting_approval':
        return { label: 'Action Required: Approve Proof', color: 'bg-amber-50 text-amber-800 border-amber-300 font-bold' };
      case 'advance_paid':
        return { label: 'Advance Paid & Scheduled', color: 'bg-indigo-50 text-indigo-700 border-indigo-200' };
      case 'printing':
        return { label: 'Printing / Hardware Work', color: 'bg-cyan-50 text-cyan-700 border-cyan-200' };
      case 'quality_check':
        return { label: 'Quality Check Inspection', color: 'bg-orange-50 text-orange-700 border-orange-200' };
      case 'packing':
        return { label: 'Packing & Invoicing', color: 'bg-emerald-50 text-emerald-700 border-emerald-200' };
      case 'ready_delivery':
        return { label: 'Ready for Counter Delivery', color: 'bg-emerald-100 text-emerald-800 border-emerald-300 font-bold' };
      case 'cancelled':
        return { label: 'Cancelled & Refunded', color: 'bg-rose-50 text-rose-700 border-rose-200' };
      default:
        return { label: status, color: 'bg-slate-50 text-slate-700 border-slate-200' };
    }
  };

  const handleConfirmApproval = () => {
    if (!selectedProofOrder || !legalConsentChecked) return;
    const legalStatement =
      'I approve this design, text, spelling, and colors for final print. I understand that physical printing will lock after this point.';
    onApproveDesign(selectedProofOrder.id, legalStatement);
    setSelectedProofOrder(null);
    setLegalConsentChecked(false);
  };

  const handleExecuteCancel = () => {
    if (!cancelModalOrder) return;
    onCancelOrder(cancelModalOrder.id, cancellationReason);
    setCancelModalOrder(null);
  };

  return (
    <div className="space-y-8">
      {/* Header and Summary Strip */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-200">
        <div>
          <div className="flex items-center gap-2 text-xs text-slate-500 mb-1">
            <span>Customer Portal</span>
            <span aria-hidden="true">·</span>
            <span>Live Order Tracker</span>
            <span aria-hidden="true">·</span>
            <span>Design Proof Sign-Off</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-slate-900">
            My Orders, Approvals & Receipts
          </h1>
        </div>

        {/* Filter controls */}
        <div className="flex items-center gap-1.5 bg-slate-100 p-1 rounded-lg">
          <button
            onClick={() => setActiveFilter('all')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors cursor-pointer ${
              activeFilter === 'all' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            All Orders ({userOrders.length})
          </button>
          <button
            onClick={() => setActiveFilter('needs_approval')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors cursor-pointer relative ${
              activeFilter === 'needs_approval' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Pending Approval ({pendingApprovalOrders.length})
          </button>
          <button
            onClick={() => setActiveFilter('active')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors cursor-pointer ${
              activeFilter === 'active' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            In-Progress
          </button>
        </div>
      </div>

      {/* Prominent Design Approval Gate Alert */}
      {pendingApprovalOrders.length > 0 && (
        <div className="p-5 bg-amber-50 border-2 border-amber-300 rounded-xl flex flex-col md:flex-row items-start md:items-center justify-between gap-4 shadow-sm">
          <div className="space-y-1">
            <div className="flex items-center gap-2 text-amber-900 font-bold text-sm">
              <FileCheck className="w-5 h-5 text-amber-700" />
              <span>Design Approval Required: {pendingApprovalOrders.length} Order Waiting For Sign-Off</span>
            </div>
            <p className="text-xs text-amber-800 leading-relaxed max-w-2xl">
              Our studio designer has uploaded the production-ready print proof for Order #{pendingApprovalOrders[0].orderId}. Physical printing cannot unlock until you visually review and click the legal sign-off.
            </p>
          </div>
          <button
            onClick={() => setSelectedProofOrder(pendingApprovalOrders[0])}
            className="px-4 py-2 text-xs font-bold text-white bg-amber-800 hover:bg-amber-900 rounded-lg transition-colors shrink-0 shadow-xs cursor-pointer flex items-center gap-1.5"
          >
            <Eye className="w-4 h-4" />
            Inspect & Approve Proof
          </button>
        </div>
      )}

      {/* Orders List */}
      <div className="space-y-4">
        {filteredOrders.length === 0 ? (
          <div className="bg-white rounded-xl border border-slate-200 p-12 text-center space-y-3">
            <Printer className="w-10 h-10 text-slate-400 mx-auto" />
            <h3 className="text-base font-bold text-slate-900">No orders found in this filter</h3>
            <p className="text-xs text-slate-500 max-w-sm mx-auto">
              You do not have any active orders matching this criterion. Try designing a custom t-shirt or booking a mobile repair.
            </p>
            <button
              onClick={onNavigateToStudio}
              className="mt-2 px-4 py-2 text-xs font-semibold text-white bg-slate-900 rounded-lg hover:bg-slate-800 transition-colors"
            >
              Open Custom Print Studio
            </button>
          </div>
        ) : (
          filteredOrders.map((order) => {
            const statusConfig = getStatusBadge(order.orderStatus);
            const isAwaitingCustomerSignoff =
              order.orderStatus === 'awaiting_approval' && !order.customerDesignApproval.isApproved;
            const isCancellationEligible = order.canCancel && order.orderStatus === 'order_received';

            return (
              <div
                key={order.id}
                className="bg-white rounded-xl border border-slate-200 p-6 space-y-4 hover:border-slate-300 transition-colors shadow-2xs"
              >
                {/* Top row */}
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-100">
                  <div className="flex items-center gap-3">
                    <span className="font-mono-numbers font-bold text-slate-900 text-sm">
                      {order.orderId}
                    </span>
                    <span className="text-xs text-slate-400">·</span>
                    <span className="text-xs font-medium text-slate-600 uppercase tracking-wider">
                      {order.category}
                    </span>
                    <span className="text-xs text-slate-400">·</span>
                    <span className="text-xs text-slate-500 font-mono-numbers">
                      {new Date(order.createdAt).toLocaleDateString([], { month: 'short', day: 'numeric', year: 'numeric' })}
                    </span>
                  </div>

                  <div className="flex items-center gap-2">
                    <span
                      className={`px-3 py-1 rounded-md text-xs font-semibold border ${statusConfig.color}`}
                    >
                      {statusConfig.label}
                    </span>
                  </div>
                </div>

                {/* Main Details Grid */}
                <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-center">
                  <div className="md:col-span-6 space-y-1.5">
                    <h3 className="text-sm font-bold text-slate-900">{order.productType}</h3>

                    {order.customization.text && (
                      <p className="text-xs text-slate-600">
                        <span className="font-semibold text-slate-700">Custom Text: </span>
                        "{order.customization.text}"
                      </p>
                    )}

                    {order.customization.deviceBrand && (
                      <p className="text-xs text-slate-600">
                        <span className="font-semibold text-slate-700">Device: </span>
                        {order.customization.deviceBrand} {order.customization.deviceModel}
                        {order.customization.issueTypes && ` · ${order.customization.issueTypes.join(', ')}`}
                      </p>
                    )}

                    {order.customization.cscFormType && (
                      <p className="text-xs text-slate-600">
                        <span className="font-semibold text-slate-700">Application: </span>
                        {order.customization.cscFormType} (Ref: {order.customization.applicantAadhaarOrId})
                      </p>
                    )}

                    <div className="flex items-center gap-4 text-xs text-slate-500 pt-1">
                      <span>Qty: {order.quantity}</span>
                      <span>·</span>
                      <span>Target Delivery: {order.deliveryDate}</span>
                    </div>
                  </div>

                  {/* Financial Breakdown */}
                  <div className="md:col-span-3 space-y-1 bg-slate-50 p-3 rounded-lg border border-slate-100 text-xs">
                    <div className="flex justify-between">
                      <span className="text-slate-500">Total Price:</span>
                      <span className="font-mono-numbers font-bold text-slate-900">₹{order.totalPrice}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-500">Advance Paid:</span>
                      <span className="font-mono-numbers font-semibold text-emerald-700">₹{order.advancePaid}</span>
                    </div>
                    <div className="flex justify-between border-t border-slate-200 pt-1">
                      <span className="text-slate-500">Balance Due:</span>
                      <span className="font-mono-numbers font-bold text-slate-800">
                        ₹{order.balanceRemaining}
                      </span>
                    </div>
                  </div>

                  {/* Action Buttons */}
                  <div className="md:col-span-3 flex flex-col gap-2">
                    {/* Design Approval Gate button */}
                    {isAwaitingCustomerSignoff ? (
                      <button
                        onClick={() => setSelectedProofOrder(order)}
                        className="w-full py-2 px-3 text-xs font-bold text-white bg-amber-600 hover:bg-amber-700 rounded-lg transition-colors flex items-center justify-center gap-1.5 shadow-xs cursor-pointer"
                      >
                        <Eye className="w-3.5 h-3.5" />
                        Inspect & Approve Proof
                      </button>
                    ) : order.customerDesignApproval.isApproved ? (
                      <div className="text-[11px] text-emerald-700 flex items-center gap-1 bg-emerald-50 p-2 rounded border border-emerald-200">
                        <CheckCircle2 className="w-3.5 h-3.5 shrink-0" />
                        <span>Design Legally Approved</span>
                      </div>
                    ) : null}

                    {/* Accidental cancellation safety button */}
                    {isCancellationEligible ? (
                      <button
                        onClick={() => setCancelModalOrder(order)}
                        className="w-full py-1.5 px-3 text-xs font-semibold text-rose-700 bg-rose-50 border border-rose-200 rounded-lg hover:bg-rose-100 transition-colors cursor-pointer flex items-center justify-center gap-1"
                        title="Allowed strictly before staff starts designing"
                      >
                        <RotateCcw className="w-3.5 h-3.5" />
                        Cancel & Instant Refund
                      </button>
                    ) : order.orderStatus === 'cancelled' ? (
                      <div className="text-[11px] text-rose-700 bg-rose-50 p-1.5 rounded text-center font-medium">
                        Refund of ₹{order.advancePaid} credited to wallet
                      </div>
                    ) : (
                      <span className="text-[10px] text-slate-400 text-center">
                        Cancellation locked (processing underway)
                      </span>
                    )}

                    {/* Printable Receipt */}
                    <button
                      onClick={() => onViewInvoice(order)}
                      className="w-full py-1.5 px-3 text-xs font-medium text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-50 transition-colors flex items-center justify-center gap-1 cursor-pointer"
                    >
                      <Receipt className="w-3.5 h-3.5 text-slate-500" />
                      View Invoice / Receipt
                    </button>
                  </div>
                </div>

                {/* Timeline Progress Tracker */}
                <div className="pt-3 border-t border-slate-100">
                  <span className="text-[11px] font-semibold text-slate-600 block mb-2">
                    Operational Workflow History:
                  </span>
                  <div className="flex flex-wrap gap-2 text-xs">
                    {order.timeline.map((event, idx) => (
                      <div
                        key={idx}
                        className="bg-slate-100 text-slate-700 px-2.5 py-1 rounded text-[11px] flex items-center gap-1.5"
                      >
                        <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                        <span className="font-semibold">{event.label}</span>
                        <span className="text-slate-400 text-[10px]">{event.timestamp}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* DESIGN APPROVAL GATE MODAL */}
      {selectedProofOrder && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/70 backdrop-blur-xs p-4 overflow-y-auto">
          <div className="w-full max-w-3xl bg-white rounded-xl shadow-2xl border border-slate-200 overflow-hidden my-8">
            <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 bg-slate-50">
              <div>
                <h3 className="text-base font-bold text-slate-900">
                  Design Proof Approval Gate · {selectedProofOrder.orderId}
                </h3>
                <p className="text-xs text-slate-500">
                  Mandatory Customer Sign-Off Required Before Physical Printing
                </p>
              </div>
              <button
                onClick={() => setSelectedProofOrder(null)}
                className="text-slate-400 hover:text-slate-700 p-1 text-sm font-bold"
              >
                ✕
              </button>
            </div>

            <div className="p-6 space-y-6">
              {/* Proof Comparison */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {/* Customer upload */}
                <div className="space-y-2">
                  <span className="text-xs font-semibold text-slate-700 block">
                    1. Your Uploaded Reference / Text:
                  </span>
                  <div className="h-64 rounded-xl border border-slate-200 bg-slate-50 flex flex-col items-center justify-center p-4 overflow-hidden">
                    {selectedProofOrder.customerDesignFile ? (
                      <img
                        src={selectedProofOrder.customerDesignFile}
                        alt="Customer Artwork"
                        className="max-h-full object-contain"
                        referrerPolicy="no-referrer"
                      />
                    ) : (
                      <div className="text-center space-y-2">
                        <Printer className="w-8 h-8 text-slate-400 mx-auto" />
                        <p className="text-xs font-mono font-medium text-slate-800">
                          "{selectedProofOrder.customization.text || 'Standard Specification'}"
                        </p>
                        <span className="text-[11px] text-slate-500">Submitted directly by customer</span>
                      </div>
                    )}
                  </div>
                </div>

                {/* Studio Calibrated Production Proof */}
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-slate-900 flex items-center gap-1.5">
                      <ShieldCheck className="w-4 h-4 text-emerald-600" />
                      2. Studio Production Proof (Print Ready):
                    </span>
                    <span className="text-[10px] font-mono-numbers text-slate-500 bg-slate-100 px-2 py-0.5 rounded">
                      300 DPI CMYK
                    </span>
                  </div>
                  <div className="h-64 rounded-xl border-2 border-emerald-500 bg-emerald-50/20 flex items-center justify-center p-2 overflow-hidden relative">
                    <img
                      src={
                        selectedProofOrder.adminDesignProofUrl ||
                        'https://images.unsplash.com/photo-1503342217505-b0a15ec3261c?auto=format&fit=crop&w=800&q=80'
                      }
                      alt="Calibrated Production Proof"
                      className="max-h-full object-contain shadow-sm rounded"
                      referrerPolicy="no-referrer"
                    />
                    <div className="absolute bottom-2 left-2 right-2 bg-slate-950/80 text-white text-[10px] p-1.5 rounded text-center backdrop-blur-xs">
                      Calibrated with Bleed Margins & Sublimation Heat Tolerances
                    </div>
                  </div>
                </div>
              </div>

              {/* Legal Declaration Checkbox */}
              <div className="p-4 bg-amber-50 border border-amber-200 rounded-xl space-y-3">
                <label className="flex items-start gap-3 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={legalConsentChecked}
                    onChange={(e) => setLegalConsentChecked(e.target.checked)}
                    className="mt-1 w-4 h-4 rounded border-amber-400 text-slate-900 focus:ring-slate-900"
                  />
                  <div className="text-xs text-amber-950 leading-relaxed">
                    <span className="font-bold block text-sm mb-1">
                      "I approve this design, text, spelling, and colors for final print."
                    </span>
                    <p className="text-[11px] text-amber-800">
                      By checking this legal confirmation, I acknowledge that I have verified spelling, layout, orientation, and color scheme. Once confirmed, physical sublimation and fabric cutting begins immediately and changes can no longer be made.
                    </p>
                  </div>
                </label>
              </div>

              {/* Action buttons */}
              <div className="flex items-center justify-between pt-3 border-t border-slate-200">
                <button
                  type="button"
                  onClick={() => setSelectedProofOrder(null)}
                  className="px-4 py-2 text-xs font-medium text-slate-700 border border-slate-300 rounded-lg hover:bg-slate-50 transition-colors"
                >
                  Cancel / Close
                </button>
                <button
                  type="button"
                  disabled={!legalConsentChecked}
                  onClick={handleConfirmApproval}
                  className="px-5 py-2.5 text-xs font-bold text-white bg-slate-900 hover:bg-slate-800 rounded-lg transition-colors disabled:opacity-40 flex items-center gap-2 shadow-xs cursor-pointer"
                >
                  <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                  Legally Sign & Unlock Printing
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ACCIDENTAL PURCHASE CANCELLATION MODAL */}
      {cancelModalOrder && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 backdrop-blur-xs p-4">
          <div className="w-full max-w-md bg-white rounded-xl shadow-2xl border border-slate-200 p-6 space-y-4">
            <div className="flex items-center gap-3 text-rose-600">
              <AlertTriangle className="w-6 h-6 shrink-0" />
              <div>
                <h3 className="text-base font-bold text-slate-900">Cancel Order & Instant Refund</h3>
                <span className="text-xs text-slate-500">Order ID: {cancelModalOrder.orderId}</span>
              </div>
            </div>

            <p className="text-xs text-slate-600 leading-relaxed">
              Because this order is still in <span className="font-semibold text-blue-700">Order Received</span> state and our production team has not begun designing or hardware diagnostics, you are protected by the{' '}
              <span className="font-semibold">Accidental Purchase Guarantee</span>.
            </p>

            <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-lg text-emerald-800 text-xs flex justify-between items-center">
              <span>Instant Refund Amount:</span>
              <span className="font-mono-numbers font-bold text-sm">₹{cancelModalOrder.advancePaid}</span>
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">
                Reason for Cancellation:
              </label>
              <select
                value={cancellationReason}
                onChange={(e) => setCancellationReason(e.target.value)}
                className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-slate-900 bg-white"
              >
                <option value="Accidental purchase / clicked by mistake">Accidental purchase / clicked by mistake</option>
                <option value="Ordered wrong product size or color">Ordered wrong product size or color</option>
                <option value="Device repair no longer needed">Device repair no longer needed</option>
                <option value="Duplicate order placed">Duplicate order placed</option>
              </select>
            </div>

            <div className="flex gap-2 pt-2">
              <button
                type="button"
                onClick={() => setCancelModalOrder(null)}
                className="flex-1 py-2 text-xs font-medium text-slate-700 border border-slate-300 rounded-lg hover:bg-slate-50"
              >
                Keep Order
              </button>
              <button
                type="button"
                onClick={handleExecuteCancel}
                className="flex-1 py-2 text-xs font-bold text-white bg-rose-600 hover:bg-rose-700 rounded-lg transition-colors cursor-pointer"
              >
                Confirm Cancellation
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
