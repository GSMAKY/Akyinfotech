import React from 'react';
import { User } from '../types';
import { Shield, Sparkles, User as UserIcon, LogOut, ArrowRightLeft } from 'lucide-react';

interface NavbarProps {
  activeView: 'home' | 'csc' | 'mobile' | 'printing' | 'orders' | 'admin' | 'blueprint';
  onNavigate: (view: 'home' | 'csc' | 'mobile' | 'printing' | 'orders' | 'admin' | 'blueprint') => void;
  currentUser: User;
  isAdminMode: boolean;
  onToggleAdmin: () => void;
  onOpenAuth: () => void;
  pendingApprovalsCount: number;
}

export const Navbar: React.FC<NavbarProps> = ({
  activeView,
  onNavigate,
  currentUser,
  isAdminMode,
  onToggleAdmin,
  onOpenAuth,
  pendingApprovalsCount,
}) => {
  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-slate-200">
      <div className="max-w-7xl mx-auto flex items-center justify-between gap-8 px-4 sm:px-6 py-3.5">
        {/* Zone 1: Single text element wordmark */}
        <button
          onClick={() => onNavigate('home')}
          className="text-lg font-bold tracking-tight text-slate-900 whitespace-nowrap shrink-0 hover:text-slate-700 transition-colors cursor-pointer text-left"
        >
          SevaPrint Hub
        </button>

        {/* Zone 2: 4-5 clean single-line text navigation links */}
        <nav className="hidden md:flex items-center gap-6 text-sm font-medium text-slate-600">
          <button
            onClick={() => onNavigate('csc')}
            className={`hover:text-slate-900 transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
              activeView === 'csc' ? 'text-slate-950 font-semibold' : ''
            }`}
          >
            CSC Services
          </button>
          <button
            onClick={() => onNavigate('mobile')}
            className={`hover:text-slate-900 transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
              activeView === 'mobile' ? 'text-slate-950 font-semibold' : ''
            }`}
          >
            Mobile Repair
          </button>
          <button
            onClick={() => onNavigate('printing')}
            className={`hover:text-slate-900 transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
              activeView === 'printing' ? 'text-slate-950 font-semibold' : ''
            }`}
          >
            Custom Printing
          </button>
          <button
            onClick={() => onNavigate('orders')}
            className={`hover:text-slate-900 transition-colors whitespace-nowrap shrink-0 cursor-pointer flex items-center gap-1.5 ${
              activeView === 'orders' ? 'text-slate-950 font-semibold' : ''
            }`}
          >
            <span>My Orders & Approvals</span>
            {pendingApprovalsCount > 0 && (
              <span className="w-2 h-2 rounded-full bg-amber-500" title="Action required" />
            )}
          </button>
          <button
            onClick={() => onNavigate('blueprint')}
            className={`hover:text-slate-900 transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
              activeView === 'blueprint' ? 'text-slate-950 font-semibold' : ''
            }`}
          >
            System Blueprint
          </button>
        </nav>

        {/* Zone 3: 1 primary action block */}
        <div className="flex items-center gap-3 shrink-0">
          {/* Fast Role Switcher */}
          <button
            onClick={onToggleAdmin}
            className={`px-3 py-1.5 text-xs font-semibold rounded-lg border transition-colors whitespace-nowrap shrink-0 flex items-center gap-1.5 cursor-pointer ${
              isAdminMode
                ? 'bg-amber-50 text-amber-900 border-amber-300 hover:bg-amber-100'
                : 'bg-slate-50 text-slate-700 border-slate-300 hover:bg-slate-100'
            }`}
          >
            <ArrowRightLeft className="w-3.5 h-3.5" />
            <span>{isAdminMode ? 'Switch to Customer View' : 'Admin Panel'}</span>
          </button>

          {/* User Profile / OTP Login */}
          <button
            onClick={onOpenAuth}
            className="px-3 py-1.5 text-xs font-medium text-white bg-slate-900 rounded-lg hover:bg-slate-800 transition-colors whitespace-nowrap shrink-0 flex items-center gap-1.5 cursor-pointer"
          >
            <UserIcon className="w-3.5 h-3.5" />
            <span className="max-w-[100px] truncate">{currentUser.name.split(' ')[0]}</span>
            <span className="text-slate-400 font-mono-numbers text-[11px] font-semibold">₹{currentUser.walletBalance}</span>
          </button>
        </div>
      </div>
    </header>
  );
};
