import React, { useState } from 'react';
import { ServiceItem, Order, User } from '../types';
import { ASSET_PATHS } from '../data/mockData';
import { Wrench, Shield, Smartphone, Clock, CheckCircle2, AlertTriangle, Calendar } from 'lucide-react';

interface MobileRepairKioskProps {
  services: ServiceItem[];
  currentUser: User;
  onOrderCreated: (newOrder: Order) => void;
  onNavigateToOrders: () => void;
}

const POPULAR_BRANDS = [
  'Apple iPhone',
  'Samsung Galaxy',
  'OnePlus',
  'Xiaomi / Redmi',
  'Vivo',
  'Realme',
  'Google Pixel',
  'Nothing Phone',
  'Oppo',
];

const ISSUE_CATALOG = [
  { id: 'screen', label: 'Cracked Screen / Touch Glitch', baseCost: 1850, turnaround: '2 hours' },
  { id: 'battery', label: 'Battery Drain / Swollen Battery', baseCost: 899, turnaround: '1 hour' },
  { id: 'water', label: 'Water / Liquid Damage Ultrasound', baseCost: 650, turnaround: '12 hours' },
  { id: 'charging', label: 'Type-C / Lightning Loose Charging', baseCost: 450, turnaround: '1 hour' },
  { id: 'motherboard', label: 'Motherboard IC / Dead Phone No Power', baseCost: 1400, turnaround: '24 hours' },
  { id: 'camera', label: 'Camera Blurry / Broken Glass Lens', baseCost: 750, turnaround: '2 hours' },
  { id: 'speaker', label: 'Ear Speaker / Microphone Low Sound', baseCost: 350, turnaround: '1 hour' },
];

export const MobileRepairKiosk: React.FC<MobileRepairKioskProps> = ({
  currentUser,
  onOrderCreated,
  onNavigateToOrders,
}) => {
  const [selectedBrand, setSelectedBrand] = useState('Apple iPhone');
  const [modelName, setModelName] = useState('iPhone 13');
  const [selectedIssues, setSelectedIssues] = useState<string[]>(['screen']);
  const [customDescription, setCustomDescription] = useState('Glass cracked near top left speaker after drop. Touch screen is working intermittently.');
  const [preferredSlot, setPreferredSlot] = useState('Today (Express 2-Hour Slot)');
  const [advanceChoice, setAdvanceChoice] = useState<'advance' | 'full'>('advance');
  const [customerName, setCustomerName] = useState(currentUser.name);
  const [customerPhone, setCustomerPhone] = useState(currentUser.phone);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [bookedOrderId, setBookedOrderId] = useState<string | null>(null);

  // Compute live estimated cost
  const calculatedTotal = selectedIssues.reduce((sum, issueId) => {
    const item = ISSUE_CATALOG.find((x) => x.id === issueId);
    return sum + (item ? item.baseCost : 0);
  }, 0) || 500;

  const advanceRequired = advanceChoice === 'full' ? calculatedTotal : Math.round(calculatedTotal * 0.4);
  const balanceDue = calculatedTotal - advanceRequired;

  const toggleIssue = (issueId: string) => {
    setSelectedIssues((prev) =>
      prev.includes(issueId)
        ? prev.filter((id) => id !== issueId)
        : [...prev, issueId]
    );
  };

  const handleBookRepair = (e: React.FormEvent) => {
    e.preventDefault();
    if (selectedIssues.length === 0) return;

    setIsSubmitting(true);
    setTimeout(() => {
      const uniqueSuffix = Math.floor(1000 + Math.random() * 9000);
      const orderCode = `ORD-2026-${uniqueSuffix}`;

      const selectedLabels = selectedIssues.map(
        (id) => ISSUE_CATALOG.find((x) => x.id === id)?.label || id
      );

      const newOrder: Order = {
        id: 'ord_' + Date.now(),
        orderId: orderCode,
        customerName: customerName || currentUser.name,
        customerPhone: customerPhone || currentUser.phone,
        customerEmail: currentUser.email,
        category: 'mobile',
        serviceId: 'srv_mob_repair_custom',
        productType: `${selectedBrand} ${modelName} Repair`,
        quantity: 1,
        customization: {
          deviceBrand: selectedBrand,
          deviceModel: modelName,
          issueTypes: selectedLabels,
          issueDescription: customDescription,
          preferredSlot: preferredSlot,
          imeiOrSerial: 'Device Registered at Counter',
        },
        totalPrice: calculatedTotal,
        advancePaid: advanceRequired,
        balanceRemaining: balanceDue,
        deliveryDate: new Date(Date.now() + 24 * 3600 * 1000).toISOString().split('T')[0],
        orderStatus: 'order_received',
        customerDesignApproval: {
          isApproved: false, // For mobile repair, represents quotation and diagnostic sign-off
        },
        canCancel: true, // Eligible for cancellation before physical teardown starts
        createdAt: new Date().toISOString(),
        timeline: [
          {
            status: 'order_received',
            label: 'Repair Slot Reserved',
            timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
            actor: 'customer',
            note: `Issues: ${selectedLabels.join(', ')}. Express bench reserved.`,
          },
        ],
      };

      onOrderCreated(newOrder);
      setIsSubmitting(false);
      setBookedOrderId(orderCode);
    }, 500);
  };

  return (
    <div className="space-y-8">
      {/* Hero Split */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center bg-white border border-slate-200 rounded-xl p-6 sm:p-8">
        <div className="lg:col-span-7 space-y-4">
          <div className="flex items-center gap-2 text-xs text-slate-500">
            <span>Electronics & Mobile Lab</span>
            <span aria-hidden="true">·</span>
            <span>Micro-Soldering Workstation</span>
            <span aria-hidden="true">·</span>
            <span>OEM Parts & Warranty</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-slate-900">
            Certified Smartphone Diagnostics & Hardware Repair Hub
          </h1>
          <p className="text-sm text-slate-600 leading-relaxed max-w-2xl">
            From cracked AMOLED screens and high-drain battery restoration to micro-soldering IC diagnostics and water damage recovery. Transparent parts quotation, live status tracking, and strict zero-pin privacy protocols.
          </p>

          {/* Privacy Guarantee Banner */}
          <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-lg flex items-start gap-3">
            <Shield className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
            <div className="text-xs">
              <span className="font-semibold text-slate-900 block">
                Strict Customer Privacy Policy (Zero Lock PIN Required)
              </span>
              <p className="text-slate-600 mt-0.5">
                Our technicians test hardware (touch digitizer, cameras, speakers, charging) inside official hardware Diagnostic / Maintenance Mode. Your personal photos, WhatsApp, and private apps remain inaccessible.
              </p>
            </div>
          </div>
        </div>

        <div className="lg:col-span-5 relative rounded-lg overflow-hidden border border-slate-200 h-56 sm:h-64">
          <img
            src={ASSET_PATHS.mobileRepair}
            alt="Mobile Repair Technician Workbench"
            className="w-full h-full object-cover"
            referrerPolicy="no-referrer"
          />
        </div>
      </div>

      {/* Booking Form & Live Diagnostic Estimator */}
      {bookedOrderId ? (
        <div className="bg-white rounded-xl border border-slate-200 p-8 text-center max-w-lg mx-auto space-y-4 shadow-sm">
          <div className="w-12 h-12 bg-emerald-100 text-emerald-700 rounded-full flex items-center justify-center mx-auto">
            <CheckCircle2 className="w-6 h-6" />
          </div>
          <h3 className="text-xl font-bold text-slate-900">Repair Slot Booked!</h3>
          <p className="text-xs text-slate-600">
            Your repair ticket has been created with Order ID{' '}
            <span className="font-mono-numbers font-bold text-slate-900">{bookedOrderId}</span> for{' '}
            <span className="font-semibold">{selectedBrand} {modelName}</span>.
          </p>

          <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-lg text-left text-xs space-y-1">
            <div className="flex justify-between">
              <span className="text-slate-500">Selected Time Slot:</span>
              <span className="font-semibold text-slate-800">{preferredSlot}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-500">Estimated Total:</span>
              <span className="font-mono-numbers font-bold text-slate-900">₹{calculatedTotal}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-500">Advance Recorded:</span>
              <span className="font-mono-numbers text-emerald-700">₹{advanceRequired}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-500">Balance on Pickup:</span>
              <span className="font-mono-numbers font-semibold text-slate-800">₹{balanceDue}</span>
            </div>
          </div>

          <div className="pt-2 flex items-center justify-center gap-3">
            <button
              onClick={() => { setBookedOrderId(null); onNavigateToOrders(); }}
              className="px-4 py-2 text-xs font-semibold text-white bg-slate-900 rounded-lg hover:bg-slate-800 transition-colors cursor-pointer"
            >
              Track in My Orders
            </button>
            <button
              onClick={() => setBookedOrderId(null)}
              className="px-4 py-2 text-xs font-medium text-slate-700 border border-slate-300 rounded-lg hover:bg-slate-50 transition-colors"
            >
              Book Another Repair
            </button>
          </div>
        </div>
      ) : (
        <form onSubmit={handleBookRepair} className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          {/* Left: Device & Issue Config */}
          <div className="lg:col-span-8 bg-white rounded-xl border border-slate-200 p-6 space-y-6">
            <div>
              <h2 className="text-base font-bold text-slate-900 mb-1">1. Select Your Device</h2>
              <p className="text-xs text-slate-500 mb-4">Choose your manufacturer and specify the exact model</p>

              {/* Brand chips */}
              <div className="flex flex-wrap gap-2 mb-4">
                {POPULAR_BRANDS.map((brand) => (
                  <button
                    key={brand}
                    type="button"
                    onClick={() => setSelectedBrand(brand)}
                    className={`px-3 py-1.5 text-xs font-medium rounded-lg border transition-colors cursor-pointer ${
                      selectedBrand === brand
                        ? 'bg-slate-900 text-white border-slate-900'
                        : 'bg-slate-50 text-slate-700 border-slate-200 hover:border-slate-300'
                    }`}
                  >
                    {brand}
                  </button>
                ))}
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">
                  Device Model Name
                </label>
                <input
                  type="text"
                  required
                  value={modelName}
                  onChange={(e) => setModelName(e.target.value)}
                  className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-slate-900"
                  placeholder="e.g. Galaxy S23 Ultra, iPhone 14 Pro, Redmi Note 12"
                />
              </div>
            </div>

            <div className="pt-6 border-t border-slate-100">
              <h2 className="text-base font-bold text-slate-900 mb-1">2. Diagnostic Issues & Faults</h2>
              <p className="text-xs text-slate-500 mb-4">Select all symptoms observed on the phone</p>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {ISSUE_CATALOG.map((item) => {
                  const isChecked = selectedIssues.includes(item.id);
                  return (
                    <div
                      key={item.id}
                      onClick={() => toggleIssue(item.id)}
                      className={`p-3.5 rounded-lg border cursor-pointer transition-colors flex items-start justify-between ${
                        isChecked
                          ? 'border-slate-900 bg-slate-50/80'
                          : 'border-slate-200 hover:border-slate-300 bg-white'
                      }`}
                    >
                      <div className="space-y-1">
                        <div className="flex items-center gap-2">
                          <input
                            type="checkbox"
                            checked={isChecked}
                            onChange={() => {}}
                            className="rounded border-slate-300 text-slate-900 focus:ring-slate-900"
                          />
                          <span className="text-xs font-semibold text-slate-900">{item.label}</span>
                        </div>
                        <span className="text-[11px] text-slate-400 block pl-5">
                          Est. Turnaround: {item.turnaround}
                        </span>
                      </div>
                      <span className="text-xs font-bold text-slate-900 font-mono-numbers">
                        ₹{item.baseCost}
                      </span>
                    </div>
                  );
                })}
              </div>
            </div>

            <div className="pt-6 border-t border-slate-100 space-y-4">
              <h2 className="text-base font-bold text-slate-900 mb-1">3. Problem Description & Bench Slot</h2>

              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">
                  Specific Fault Description / Additional Notes
                </label>
                <textarea
                  rows={2}
                  value={customDescription}
                  onChange={(e) => setCustomDescription(e.target.value)}
                  className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-slate-900"
                  placeholder="Detail symptoms (e.g. occurred after rainfall, no charging sound, touch freezes after 5 minutes)..."
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">
                    Preferred Drop-off / Express Bench Slot
                  </label>
                  <select
                    value={preferredSlot}
                    onChange={(e) => setPreferredSlot(e.target.value)}
                    className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-slate-900 bg-white"
                  >
                    <option value="Today (Express 2-Hour Slot)">Today (Express 2-Hour Slot)</option>
                    <option value="Tomorrow Morning (10:00 AM - 1:00 PM)">Tomorrow Morning (10:00 AM - 1:00 PM)</option>
                    <option value="Tomorrow Afternoon (2:00 PM - 6:00 PM)">Tomorrow Afternoon (2:00 PM - 6:00 PM)</option>
                    <option value="Weekend Drop-off">Weekend Drop-off</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">
                    Contact Phone Number (+91)
                  </label>
                  <input
                    type="tel"
                    required
                    maxLength={10}
                    value={customerPhone}
                    onChange={(e) => setCustomerPhone(e.target.value.replace(/\D/g, ''))}
                    className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-slate-900 font-mono-numbers"
                    placeholder="9876543210"
                  />
                </div>
              </div>
            </div>
          </div>

          {/* Right: Price Summary & Instant Booking */}
          <div className="lg:col-span-4 space-y-6">
            <div className="bg-white rounded-xl border border-slate-200 p-6 sticky top-20 space-y-5">
              <h3 className="text-sm font-bold text-slate-900">Live Repair Quotation</h3>

              <div className="space-y-3 pb-4 border-b border-slate-100 text-xs">
                <div className="flex justify-between text-slate-600">
                  <span>Selected Device:</span>
                  <span className="font-semibold text-slate-800">{selectedBrand}</span>
                </div>
                <div className="flex justify-between text-slate-600">
                  <span>Model:</span>
                  <span className="font-semibold text-slate-800">{modelName || '—'}</span>
                </div>
                <div className="flex justify-between text-slate-600">
                  <span>Diagnostics Count:</span>
                  <span className="font-mono-numbers text-slate-800">{selectedIssues.length} Selected</span>
                </div>
              </div>

              {/* Cost Calculation */}
              <div className="space-y-2 text-xs">
                <div className="flex justify-between text-slate-600">
                  <span>Estimated Total (Parts + Labor):</span>
                  <span className="font-mono-numbers font-bold text-slate-900 text-sm">
                    ₹{calculatedTotal}
                  </span>
                </div>

                {/* Advance choice */}
                <div className="pt-2">
                  <label className="block text-[11px] font-semibold text-slate-700 mb-1.5">
                    Payment Option:
                  </label>
                  <div className="grid grid-cols-2 gap-2">
                    <button
                      type="button"
                      onClick={() => setAdvanceChoice('advance')}
                      className={`p-2 text-xs rounded-lg border text-center transition-colors cursor-pointer ${
                        advanceChoice === 'advance'
                          ? 'border-slate-900 bg-slate-900 text-white font-semibold'
                          : 'border-slate-200 text-slate-700 hover:border-slate-300'
                      }`}
                    >
                      <span>Deposit 40%</span>
                      <span className="block font-mono-numbers text-[11px] opacity-90">₹{Math.round(calculatedTotal * 0.4)}</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => setAdvanceChoice('full')}
                      className={`p-2 text-xs rounded-lg border text-center transition-colors cursor-pointer ${
                        advanceChoice === 'full'
                          ? 'border-slate-900 bg-slate-900 text-white font-semibold'
                          : 'border-slate-200 text-slate-700 hover:border-slate-300'
                      }`}
                    >
                      <span>Pay Full 100%</span>
                      <span className="block font-mono-numbers text-[11px] opacity-90">₹{calculatedTotal}</span>
                    </button>
                  </div>
                </div>

                <div className="flex justify-between text-slate-600 pt-2 border-t border-slate-100">
                  <span>Advance Payable Now:</span>
                  <span className="font-mono-numbers font-bold text-emerald-700 text-sm">
                    ₹{advanceRequired}
                  </span>
                </div>
                <div className="flex justify-between text-slate-500">
                  <span>Balance Due on Device Pickup:</span>
                  <span className="font-mono-numbers font-semibold text-slate-700">
                    ₹{balanceDue}
                  </span>
                </div>
              </div>

              {/* Safety notice */}
              <div className="p-3 bg-amber-50/80 border border-amber-200 rounded-lg text-amber-900 text-[11px] leading-relaxed">
                <span className="font-semibold block mb-0.5">Accidental Booking Safety:</span>
                Cancel with full automatic refund before the repair bench starts diagnostic teardown.
              </div>

              <button
                type="submit"
                disabled={isSubmitting || selectedIssues.length === 0}
                className="w-full py-2.5 px-4 text-xs font-semibold text-white bg-slate-900 rounded-lg hover:bg-slate-800 transition-colors disabled:opacity-50 cursor-pointer"
              >
                {isSubmitting ? 'Reserving Bench...' : `Confirm Slot & Deposit (₹${advanceRequired})`}
              </button>
            </div>
          </div>
        </form>
      )}
    </div>
  );
};
