import React, { useState } from 'react';
import { ServiceItem, Order, User } from '../types';
import { ASSET_PATHS } from '../data/mockData';
import { Printer, Upload, Palette, Type, CheckCircle2, RotateCcw, AlertCircle, Sparkles } from 'lucide-react';

interface CustomPrintingStudioProps {
  services: ServiceItem[];
  currentUser: User;
  onOrderCreated: (newOrder: Order) => void;
  onNavigateToOrders: () => void;
}

interface ProductTemplate {
  id: string;
  name: string;
  basePrice: number;
  mockupImage: string;
  category: 'tshirt' | 'mug' | 'clock' | 'tote' | 'card';
  availableColors: { name: string; hex: string }[];
  availableSizes?: string[];
  maxPrintWidth: string;
}

const TEMPLATES: ProductTemplate[] = [
  {
    id: 'prt_tshirt',
    name: 'Bio-Washed Cotton T-Shirt (220 GSM)',
    basePrice: 399,
    mockupImage: ASSET_PATHS.tshirtMockup,
    category: 'tshirt',
    availableColors: [
      { name: 'Pure White', hex: '#ffffff' },
      { name: 'Onyx Black', hex: '#0f172a' },
      { name: 'Navy Blue', hex: '#1e3a8a' },
      { name: 'Crimson Red', hex: '#dc2626' },
      { name: 'Forest Green', hex: '#166534' },
    ],
    availableSizes: ['S', 'M', 'L', 'XL', 'XXL'],
    maxPrintWidth: 'w-48 sm:w-56',
  },
  {
    id: 'prt_mug',
    name: 'Personalized 11oz Ceramic Coffee Mug',
    basePrice: 199,
    mockupImage: ASSET_PATHS.mugMockup,
    category: 'mug',
    availableColors: [
      { name: 'Glossy White', hex: '#ffffff' },
      { name: 'Midnight Slate', hex: '#1e293b' },
      { name: 'Soft Cream', hex: '#fef3c7' },
    ],
    maxPrintWidth: 'w-36 sm:w-44',
  },
  {
    id: 'prt_clock',
    name: 'Silent Quartz Wall Clock (12-Inch)',
    basePrice: 549,
    mockupImage: ASSET_PATHS.printingStudio,
    category: 'clock',
    availableColors: [
      { name: 'Modern White', hex: '#ffffff' },
      { name: 'Matte Black', hex: '#18181b' },
      { name: 'Natural Oak', hex: '#78350f' },
    ],
    maxPrintWidth: 'w-40 sm:w-48',
  },
];

export const CustomPrintingStudio: React.FC<CustomPrintingStudioProps> = ({
  currentUser,
  onOrderCreated,
  onNavigateToOrders,
}) => {
  const [selectedTemplate, setSelectedTemplate] = useState<ProductTemplate>(TEMPLATES[0]);
  const [selectedColor, setSelectedColor] = useState(selectedTemplate.availableColors[0].hex);
  const [selectedSize, setSelectedSize] = useState('L');
  const [customText, setCustomText] = useState('CREATIVE STUDIO 2026');
  const [textColor, setTextColor] = useState('#0f172a');
  const [fontFamily, setFontFamily] = useState('font-sans font-bold tracking-wider');
  const [uploadedLogo, setUploadedLogo] = useState<string | null>(null);
  const [logoScale, setLogoScale] = useState(80);
  const [quantity, setQuantity] = useState(2);
  const [advanceOption, setAdvanceOption] = useState<'advance' | 'full'>('advance');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [successOrderId, setSuccessOrderId] = useState<string | null>(null);

  // Price Calculation with volume discount:
  // 1-4 units: 0% discount
  // 5-19 units: 15% discount
  // 20+ units: 25% discount
  const unitPrice = selectedTemplate.basePrice;
  const rawTotal = unitPrice * quantity;
  const discountRate = quantity >= 20 ? 0.25 : quantity >= 5 ? 0.15 : 0;
  const finalTotal = Math.round(rawTotal * (1 - discountRate));
  const advanceAmount = advanceOption === 'full' ? finalTotal : Math.round(finalTotal * 0.4);
  const balanceDue = finalTotal - advanceAmount;

  const handleTemplateChange = (tmpl: ProductTemplate) => {
    setSelectedTemplate(tmpl);
    setSelectedColor(tmpl.availableColors[0].hex);
    if (tmpl.availableColors[0].hex === '#0f172a') {
      setTextColor('#ffffff');
    } else {
      setTextColor('#0f172a');
    }
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      const reader = new FileReader();
      reader.onload = (uploadEvent) => {
        setUploadedLogo(uploadEvent.target?.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleCreatePrintOrder = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    setTimeout(() => {
      const uniqueSuffix = Math.floor(1000 + Math.random() * 9000);
      const orderCode = `ORD-2026-${uniqueSuffix}`;

      const newOrder: Order = {
        id: 'ord_' + Date.now(),
        orderId: orderCode,
        customerName: currentUser.name,
        customerPhone: currentUser.phone,
        customerEmail: currentUser.email,
        category: 'printing',
        serviceId: selectedTemplate.id,
        productType: selectedTemplate.name,
        quantity: quantity,
        customization: {
          text: customText,
          textColor: textColor,
          productColor: selectedColor,
          size: selectedTemplate.category === 'tshirt' ? selectedSize : undefined,
          printSide: 'front',
        },
        customerDesignFile: uploadedLogo || undefined,
        totalPrice: finalTotal,
        advancePaid: advanceAmount,
        balanceRemaining: balanceDue,
        deliveryDate: new Date(Date.now() + 48 * 3600 * 1000).toISOString().split('T')[0],
        orderStatus: 'order_received',
        customerDesignApproval: {
          isApproved: false,
        },
        canCancel: true, // Strictly cancellable before designer starts production artwork
        createdAt: new Date().toISOString(),
        timeline: [
          {
            status: 'order_received',
            label: 'Custom Print Order Placed',
            timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
            actor: 'customer',
            note: `Quantity: ${quantity} units. Color: ${selectedColor}. Design submitted for pre-press inspection.`,
          },
        ],
      };

      onOrderCreated(newOrder);
      setIsSubmitting(false);
      setSuccessOrderId(orderCode);
    }, 500);
  };

  return (
    <div className="space-y-8">
      {/* Studio Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-200">
        <div>
          <div className="flex items-center gap-2 text-xs text-slate-500 mb-1">
            <span>Sublimation & Screen Printing Studio</span>
            <span aria-hidden="true">·</span>
            <span>Real-Time Visual Customizer</span>
            <span aria-hidden="true">·</span>
            <span>Zero-Risk Approval Gate</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-slate-900">
            Interactive Custom Merchandise & Print Lab
          </h1>
        </div>

        {/* Product selector buttons */}
        <div className="flex items-center gap-1.5 bg-slate-100 p-1 rounded-lg">
          {TEMPLATES.map((tmpl) => (
            <button
              key={tmpl.id}
              onClick={() => handleTemplateChange(tmpl)}
              className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors cursor-pointer ${
                selectedTemplate.id === tmpl.id
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              {tmpl.category === 'tshirt' ? 'T-Shirt' : tmpl.category === 'mug' ? 'Mug' : 'Wall Clock'}
            </button>
          ))}
        </div>
      </div>

      {successOrderId ? (
        <div className="bg-white rounded-xl border border-slate-200 p-8 text-center max-w-lg mx-auto space-y-4 shadow-sm">
          <div className="w-12 h-12 bg-emerald-100 text-emerald-700 rounded-full flex items-center justify-center mx-auto">
            <CheckCircle2 className="w-6 h-6" />
          </div>
          <h3 className="text-xl font-bold text-slate-900">Custom Order Created!</h3>
          <p className="text-xs text-slate-600">
            Your customized print job is registered under Order ID{' '}
            <span className="font-mono-numbers font-bold text-slate-900">{successOrderId}</span>.
          </p>
          <div className="p-4 bg-slate-50 border border-slate-200 rounded-lg text-left text-xs space-y-1.5">
            <div className="flex justify-between">
              <span className="text-slate-500">Product:</span>
              <span className="font-semibold text-slate-800">{selectedTemplate.name}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-500">Units:</span>
              <span className="font-mono-numbers font-semibold text-slate-800">{quantity}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-500">Advance Paid:</span>
              <span className="font-mono-numbers text-emerald-700 font-bold">₹{advanceAmount}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-500">Balance on Delivery:</span>
              <span className="font-mono-numbers text-slate-700 font-bold">₹{balanceDue}</span>
            </div>
          </div>

          <div className="p-3 bg-amber-50 text-amber-900 rounded-lg text-[11px] text-left">
            <span className="font-bold block mb-0.5">Next Operational Step:</span>
            Our studio designer will calibrate colors and upload a production proof to your dashboard. You will review and legally approve it before any printing takes place.
          </div>

          <div className="pt-2 flex items-center justify-center gap-3">
            <button
              onClick={() => { setSuccessOrderId(null); onNavigateToOrders(); }}
              className="px-4 py-2 text-xs font-semibold text-white bg-slate-900 rounded-lg hover:bg-slate-800 transition-colors cursor-pointer"
            >
              Track in My Orders
            </button>
            <button
              onClick={() => setSuccessOrderId(null)}
              className="px-4 py-2 text-xs font-medium text-slate-700 border border-slate-300 rounded-lg hover:bg-slate-50 transition-colors"
            >
              Design Another Product
            </button>
          </div>
        </div>
      ) : (
        <form onSubmit={handleCreatePrintOrder} className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Left: Interactive Canvas Mockup */}
          <div className="lg:col-span-7 bg-white rounded-xl border border-slate-200 p-6 flex flex-col items-center">
            <div className="w-full flex items-center justify-between mb-4">
              <span className="text-xs font-bold text-slate-800">
                Live Studio Canvas Preview
              </span>
              <span className="text-[11px] text-slate-500">
                Simulated 300 DPI Sublimation
              </span>
            </div>

            {/* Interactive Mockup Container */}
            <div className="relative w-full max-w-md aspect-square rounded-xl overflow-hidden bg-slate-100 border border-slate-200 flex items-center justify-center p-4">
              {/* Product Background Image */}
              <img
                src={selectedTemplate.mockupImage}
                alt={selectedTemplate.name}
                className="w-full h-full object-contain select-none"
                referrerPolicy="no-referrer"
              />

              {/* Tint overlay based on selected color */}
              {selectedTemplate.category === 'tshirt' && selectedColor !== '#ffffff' && (
                <div
                  className="absolute inset-0 mix-blend-multiply opacity-75 pointer-events-none transition-colors"
                  style={{ backgroundColor: selectedColor }}
                />
              )}

              {/* Live Print Overlay Area */}
              <div
                className={`absolute flex flex-col items-center justify-center text-center pointer-events-none ${
                  selectedTemplate.category === 'tshirt'
                    ? 'top-[28%] w-[45%]'
                    : selectedTemplate.category === 'mug'
                    ? 'top-[35%] left-[26%] w-[38%]'
                    : 'top-[30%] w-[42%]'
                }`}
              >
                {/* Uploaded Logo Preview */}
                {uploadedLogo && (
                  <img
                    src={uploadedLogo}
                    alt="Custom Print Artwork"
                    style={{ width: `${logoScale}%` }}
                    className="max-h-24 object-contain mb-2 drop-shadow-xs"
                  />
                )}

                {/* Custom Text Overlay */}
                {customText && (
                  <p
                    className={`${fontFamily} break-words leading-tight drop-shadow-xs px-2`}
                    style={{ color: textColor, fontSize: selectedTemplate.category === 'mug' ? '12px' : '15px' }}
                  >
                    {customText}
                  </p>
                )}
              </div>
            </div>

            {/* Canvas Hint */}
            <p className="text-[11px] text-slate-400 mt-3 text-center">
              Real-time representation. Official production proof will be uploaded by our studio team for your legal approval before print.
            </p>
          </div>

          {/* Right: Studio Customizer Controls */}
          <div className="lg:col-span-5 bg-white rounded-xl border border-slate-200 p-6 space-y-6">
            <h2 className="text-base font-bold text-slate-900 pb-3 border-b border-slate-100">
              Customize {selectedTemplate.name}
            </h2>

            {/* Color Swatches */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-2 flex items-center gap-1.5">
                <Palette className="w-3.5 h-3.5 text-slate-500" />
                Select Fabric / Base Color:
              </label>
              <div className="flex items-center gap-3">
                {selectedTemplate.availableColors.map((c) => (
                  <button
                    key={c.hex}
                    type="button"
                    title={c.name}
                    onClick={() => {
                      setSelectedColor(c.hex);
                      if (c.hex === '#0f172a' || c.hex === '#1e293b') {
                        setTextColor('#ffffff');
                      } else {
                        setTextColor('#0f172a');
                      }
                    }}
                    className={`w-7 h-7 rounded-full border-2 transition-transform cursor-pointer ${
                      selectedColor === c.hex ? 'scale-110 border-slate-900 shadow-xs' : 'border-slate-300'
                    }`}
                    style={{ backgroundColor: c.hex }}
                  />
                ))}
              </div>
            </div>

            {/* Sizes (if T-shirt) */}
            {selectedTemplate.availableSizes && (
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-2">
                  Garment Size:
                </label>
                <div className="flex gap-2">
                  {selectedTemplate.availableSizes.map((sz) => (
                    <button
                      key={sz}
                      type="button"
                      onClick={() => setSelectedSize(sz)}
                      className={`w-9 h-8 rounded-lg text-xs font-semibold border transition-colors cursor-pointer ${
                        selectedSize === sz
                          ? 'bg-slate-900 text-white border-slate-900'
                          : 'bg-slate-50 text-slate-700 border-slate-200 hover:border-slate-300'
                      }`}
                    >
                      {sz}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Text Customization */}
            <div className="space-y-3 pt-3 border-t border-slate-100">
              <label className="block text-xs font-semibold text-slate-700 flex items-center gap-1.5">
                <Type className="w-3.5 h-3.5 text-slate-500" />
                Custom Typography & Text:
              </label>
              <input
                type="text"
                value={customText}
                onChange={(e) => setCustomText(e.target.value)}
                maxLength={45}
                className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-slate-900"
                placeholder="Enter quote, club name, or slogan"
              />

              <div className="flex items-center justify-between gap-3 text-xs">
                <div className="flex items-center gap-2">
                  <span className="text-slate-500">Text Color:</span>
                  <input
                    type="color"
                    value={textColor}
                    onChange={(e) => setTextColor(e.target.value)}
                    className="w-6 h-6 rounded cursor-pointer border border-slate-200 p-0"
                  />
                </div>

                <div className="flex items-center gap-1">
                  <button
                    type="button"
                    onClick={() => setFontFamily('font-sans font-bold tracking-wider uppercase')}
                    className="px-2 py-1 text-[11px] rounded border border-slate-200 bg-slate-50 hover:bg-slate-100 font-sans font-bold"
                  >
                    Sans
                  </button>
                  <button
                    type="button"
                    onClick={() => setFontFamily('font-serif font-semibold italic')}
                    className="px-2 py-1 text-[11px] rounded border border-slate-200 bg-slate-50 hover:bg-slate-100 font-serif italic"
                  >
                    Serif
                  </button>
                  <button
                    type="button"
                    onClick={() => setFontFamily('font-mono font-medium')}
                    className="px-2 py-1 text-[11px] rounded border border-slate-200 bg-slate-50 hover:bg-slate-100 font-mono"
                  >
                    Mono
                  </button>
                </div>
              </div>
            </div>

            {/* Artwork Upload */}
            <div className="space-y-2 pt-3 border-t border-slate-100">
              <div className="flex items-center justify-between">
                <label className="text-xs font-semibold text-slate-700 flex items-center gap-1.5">
                  <Upload className="w-3.5 h-3.5 text-slate-500" />
                  Upload Vector Logo / Photo:
                </label>
                {uploadedLogo && (
                  <button
                    type="button"
                    onClick={() => setUploadedLogo(null)}
                    className="text-[11px] text-rose-600 hover:underline"
                  >
                    Remove Logo
                  </button>
                )}
              </div>

              <input
                type="file"
                id="logo-upload"
                accept="image/*"
                onChange={handleImageUpload}
                className="hidden"
              />
              <label
                htmlFor="logo-upload"
                className="block border border-dashed border-slate-300 rounded-lg p-2.5 text-center text-xs text-slate-600 hover:border-slate-500 cursor-pointer bg-slate-50"
              >
                {uploadedLogo ? 'Change Image File' : 'Click to upload PNG/JPG artwork'}
              </label>

              {uploadedLogo && (
                <div className="flex items-center gap-2 pt-1">
                  <span className="text-[11px] text-slate-500">Logo Scale:</span>
                  <input
                    type="range"
                    min="30"
                    max="100"
                    value={logoScale}
                    onChange={(e) => setLogoScale(Number(e.target.value))}
                    className="flex-1 accent-slate-900"
                  />
                  <span className="text-[11px] font-mono-numbers text-slate-700">{logoScale}%</span>
                </div>
              )}
            </div>

            {/* Quantity & Volume Discounts */}
            <div className="pt-3 border-t border-slate-100 space-y-2">
              <div className="flex items-center justify-between">
                <label className="text-xs font-semibold text-slate-700">Order Quantity:</label>
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => setQuantity(Math.max(1, quantity - 1))}
                    className="w-7 h-7 rounded border border-slate-200 bg-slate-100 text-xs font-bold"
                  >
                    -
                  </button>
                  <span className="font-mono-numbers text-sm font-bold text-slate-900 px-2">
                    {quantity}
                  </span>
                  <button
                    type="button"
                    onClick={() => setQuantity(quantity + 1)}
                    className="w-7 h-7 rounded border border-slate-200 bg-slate-100 text-xs font-bold"
                  >
                    +
                  </button>
                </div>
              </div>

              {discountRate > 0 && (
                <div className="p-2 bg-emerald-50 rounded text-emerald-800 text-[11px] font-semibold flex items-center justify-between">
                  <span>Volume Tier Discount Applied!</span>
                  <span>-{(discountRate * 100).toFixed(0)}% Off</span>
                </div>
              )}
            </div>

            {/* Pricing Summary */}
            <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-2 text-xs">
              <div className="flex justify-between text-slate-600">
                <span>Unit Base Price:</span>
                <span className="font-mono-numbers text-slate-900">₹{unitPrice}</span>
              </div>
              <div className="flex justify-between text-slate-600">
                <span>Total Amount ({quantity} units):</span>
                <span className="font-mono-numbers font-bold text-slate-900">₹{finalTotal}</span>
              </div>

              {/* Advance Options */}
              <div className="pt-2">
                <span className="text-[11px] font-semibold text-slate-700 block mb-1">
                  Payment Preference:
                </span>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setAdvanceOption('advance')}
                    className={`py-1.5 px-2 text-[11px] rounded-lg border text-center cursor-pointer ${
                      advanceOption === 'advance'
                        ? 'border-slate-900 bg-slate-900 text-white font-semibold'
                        : 'border-slate-200 text-slate-700 hover:border-slate-300'
                    }`}
                  >
                    Deposit 40% (₹{Math.round(finalTotal * 0.4)})
                  </button>
                  <button
                    type="button"
                    onClick={() => setAdvanceOption('full')}
                    className={`py-1.5 px-2 text-[11px] rounded-lg border text-center cursor-pointer ${
                      advanceOption === 'full'
                        ? 'border-slate-900 bg-slate-900 text-white font-semibold'
                        : 'border-slate-200 text-slate-700 hover:border-slate-300'
                    }`}
                  >
                    Pay Full (₹{finalTotal})
                  </button>
                </div>
              </div>

              <div className="flex justify-between text-slate-600 pt-2 border-t border-slate-200">
                <span className="font-semibold text-slate-800">Payable Advance:</span>
                <span className="font-mono-numbers font-bold text-emerald-700">₹{advanceAmount}</span>
              </div>
              <div className="flex justify-between text-slate-500">
                <span>Balance on Final Delivery:</span>
                <span className="font-mono-numbers font-medium text-slate-700">₹{balanceDue}</span>
              </div>
            </div>

            <button
              type="submit"
              disabled={isSubmitting}
              className="w-full py-2.5 px-4 text-xs font-semibold text-white bg-slate-900 rounded-lg hover:bg-slate-800 transition-colors disabled:opacity-50 cursor-pointer"
            >
              {isSubmitting ? 'Creating Order...' : `Place Custom Order (Deposit ₹${advanceAmount})`}
            </button>
          </div>
        </form>
      )}
    </div>
  );
};
