import React, { useState } from 'react';
import { ServiceItem, Order, User } from '../types';
import { ASSET_PATHS } from '../data/mockData';
import { ShieldCheck, FileText, Upload, CheckCircle2, Lock, AlertCircle, ArrowRight } from 'lucide-react';

interface CscServicesKioskProps {
  services: ServiceItem[];
  currentUser: User;
  onOrderCreated: (newOrder: Order) => void;
  onNavigateToOrders: () => void;
}

export const CscServicesKiosk: React.FC<CscServicesKioskProps> = ({
  services,
  currentUser,
  onOrderCreated,
  onNavigateToOrders,
}) => {
  const cscServices = services.filter((s) => s.category === 'csc' && s.isActive);
  const [selectedService, setSelectedService] = useState<ServiceItem | null>(null);

  // Form states
  const [applicantName, setApplicantName] = useState(currentUser.name);
  const [applicantPhone, setApplicantPhone] = useState(currentUser.phone);
  const [idNumber, setIdNumber] = useState('');
  const [serviceFormType, setServiceFormType] = useState('Fresh / New Application');
  const [uploadedFiles, setUploadedFiles] = useState<{ name: string; size: string; encryptedHash: string; type: string }[]>([]);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [orderSuccessMsg, setOrderSuccessMsg] = useState<string | null>(null);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      const fileList = Array.from(e.target.files);
      const newItems = fileList.map((f) => {
        const fakeHash = 'aes256_' + Math.random().toString(36).substring(2, 10) + '...' + Math.random().toString(36).substring(2, 6);
        return {
          name: f.name,
          size: `${(f.size / (1024 * 1024)).toFixed(2)} MB`,
          encryptedHash: fakeHash,
          type: f.type || 'application/octet-stream',
        };
      });
      setUploadedFiles((prev) => [...prev, ...newItems]);
    }
  };

  const handleOpenForm = (srv: ServiceItem) => {
    setSelectedService(srv);
    setUploadedFiles([]);
    setOrderSuccessMsg(null);
  };

  const handleSubmitCscOrder = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedService) return;

    setIsSubmitting(true);
    setTimeout(() => {
      const uniqueSuffix = Math.floor(1000 + Math.random() * 9000);
      const orderCode = `ORD-2026-${uniqueSuffix}`;

      const newOrder: Order = {
        id: 'ord_' + Date.now(),
        orderId: orderCode,
        customerName: applicantName || currentUser.name,
        customerPhone: applicantPhone || currentUser.phone,
        customerEmail: currentUser.email,
        category: 'csc',
        serviceId: selectedService.id,
        productType: selectedService.title,
        quantity: 1,
        customization: {
          cscFormType: serviceFormType,
          applicantAadhaarOrId: idNumber ? `XXXX-XXXX-${idNumber.slice(-4)}` : 'Verified Online',
          uploadedDocs: uploadedFiles.length > 0 ? uploadedFiles : [
            { name: 'Self_Attested_Aadhaar.pdf', size: '1.1 MB', encryptedHash: 'aes256_e81c...99', type: 'application/pdf' }
          ],
        },
        totalPrice: selectedService.basePrice,
        advancePaid: selectedService.basePrice, // Government portals usually take full statutory fee
        balanceRemaining: 0,
        deliveryDate: new Date(Date.now() + selectedService.turnaroundHours * 3600 * 1000).toISOString().split('T')[0],
        orderStatus: 'order_received',
        customerDesignApproval: {
          isApproved: false,
        },
        canCancel: true, // Strictly eligible for cancellation before staff processing begins
        createdAt: new Date().toISOString(),
        timeline: [
          {
            status: 'order_received',
            label: 'Application Lodged at Digital Kiosk',
            timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
            actor: 'customer',
            note: 'Application details & encrypted documents stored in compliant vault.',
          },
        ],
      };

      onOrderCreated(newOrder);
      setIsSubmitting(false);
      setOrderSuccessMsg(orderCode);
    }, 600);
  };

  return (
    <div className="space-y-8">
      {/* Hero & Trust Banner */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center bg-white border border-slate-200 rounded-xl p-6 sm:p-8">
        <div className="lg:col-span-7 space-y-4">
          <div className="flex items-center gap-2 text-xs text-slate-500">
            <span>CSC Digital Seva Kendra</span>
            <span aria-hidden="true">·</span>
            <span>Government Portal Agent</span>
            <span aria-hidden="true">·</span>
            <span>Direct NSDL & UIDAI Facilitation</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-slate-900">
            Authorized Digital Citizen Services & Online Form Kiosk
          </h1>
          <p className="text-sm text-slate-600 leading-relaxed max-w-2xl">
            Apply for PAN Cards, Aadhaar demographic corrections, caste/income certificates, passport slots, and farmer benefit schemes without long queues. All citizen records are processed under India DPDPA 2023 security compliance.
          </p>

          <div className="flex flex-wrap items-center gap-4 pt-2 text-xs text-slate-600">
            <div className="flex items-center gap-1.5">
              <ShieldCheck className="w-4 h-4 text-emerald-600" />
              <span>AES-256 Client-Side Doc Encryption</span>
            </div>
            <div className="flex items-center gap-1.5">
              <Lock className="w-4 h-4 text-emerald-600" />
              <span>14-Day Automated Ephemeral Doc Purge</span>
            </div>
          </div>
        </div>

        <div className="lg:col-span-5 relative rounded-lg overflow-hidden border border-slate-200 h-56 sm:h-64">
          <img
            src={ASSET_PATHS.cscServices}
            alt="Citizen Digital Service Center Counter"
            className="w-full h-full object-cover"
            referrerPolicy="no-referrer"
          />
        </div>
      </div>

      {/* Services Grid */}
      <div>
        <div className="flex items-center justify-between mb-4">
          <div>
            <h2 className="text-lg font-bold text-slate-900">Available Digital Forms & Certificates</h2>
            <p className="text-xs text-slate-500">Select a government service to begin your digital application</p>
          </div>
          <span className="text-xs text-slate-500 font-mono-numbers">
            {cscServices.length} Active Portals
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {cscServices.map((srv) => (
            <div
              key={srv.id}
              className="bg-white rounded-xl border border-slate-200 p-5 flex flex-col justify-between hover:border-slate-300 transition-colors"
            >
              <div className="space-y-3">
                <div className="flex items-start justify-between gap-3">
                  <h3 className="text-sm font-bold text-slate-900 leading-snug">
                    {srv.title}
                  </h3>
                  <div className="text-right shrink-0">
                    <span className="text-base font-bold text-slate-900 font-mono-numbers">
                      ₹{srv.basePrice}
                    </span>
                    <span className="block text-[10px] text-slate-400">Govt + Seva fee</span>
                  </div>
                </div>

                <p className="text-xs text-slate-600 leading-relaxed">
                  {srv.description}
                </p>

                {srv.requiredDocs && srv.requiredDocs.length > 0 && (
                  <div className="pt-2 border-t border-slate-100">
                    <span className="text-[11px] font-semibold text-slate-700 block mb-1">
                      Required Documents:
                    </span>
                    <ul className="text-[11px] text-slate-500 space-y-0.5">
                      {srv.requiredDocs.map((doc, idx) => (
                        <li key={idx} className="truncate">
                          · {doc}
                        </li>
                      ))}
                    </ul>
                  </div>
                )}
              </div>

              <div className="pt-4 mt-4 border-t border-slate-100 flex items-center justify-between">
                <span className="text-xs text-slate-500 font-mono-numbers">
                  Turnaround: {srv.turnaroundHours}h
                </span>
                <button
                  onClick={() => handleOpenForm(srv)}
                  className="px-3.5 py-1.5 text-xs font-semibold text-white bg-slate-900 rounded-lg hover:bg-slate-800 transition-colors cursor-pointer"
                >
                  Apply Online
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Online Application Modal */}
      {selectedService && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 backdrop-blur-xs p-4 overflow-y-auto">
          <div className="w-full max-w-xl bg-white rounded-xl shadow-2xl border border-slate-200 overflow-hidden my-8">
            <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 bg-slate-50">
              <div>
                <h3 className="text-base font-bold text-slate-900">{selectedService.title}</h3>
                <p className="text-xs text-slate-500">Government Portal Online Facilitation Request</p>
              </div>
              <button
                onClick={() => setSelectedService(null)}
                className="text-slate-400 hover:text-slate-700 text-sm font-semibold p-1"
              >
                ✕
              </button>
            </div>

            {orderSuccessMsg ? (
              <div className="p-8 text-center space-y-4">
                <div className="w-12 h-12 bg-emerald-100 text-emerald-700 rounded-full flex items-center justify-center mx-auto">
                  <CheckCircle2 className="w-6 h-6" />
                </div>
                <h4 className="text-lg font-bold text-slate-900">Application Lodged Successfully!</h4>
                <p className="text-xs text-slate-600 max-w-md mx-auto">
                  Your government service application has been recorded under Tracking Order ID{' '}
                  <span className="font-mono-numbers font-bold text-slate-900">{orderSuccessMsg}</span>.
                  You can track verification progress, inspect drafted receipts, or exercise the accidental cancellation window in your dashboard.
                </p>

                <div className="pt-4 flex items-center justify-center gap-3">
                  <button
                    onClick={() => { setSelectedService(null); onNavigateToOrders(); }}
                    className="px-4 py-2 text-xs font-semibold text-white bg-slate-900 rounded-lg hover:bg-slate-800 transition-colors cursor-pointer"
                  >
                    View In My Orders
                  </button>
                  <button
                    onClick={() => setSelectedService(null)}
                    className="px-4 py-2 text-xs font-medium text-slate-700 border border-slate-300 rounded-lg hover:bg-slate-50 transition-colors"
                  >
                    Done
                  </button>
                </div>
              </div>
            ) : (
              <form onSubmit={handleSubmitCscOrder} className="p-6 space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-medium text-slate-700 mb-1">
                      Applicant Full Name
                    </label>
                    <input
                      type="text"
                      required
                      value={applicantName}
                      onChange={(e) => setApplicantName(e.target.value)}
                      className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-slate-900"
                      placeholder="As per Aadhaar Card"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-slate-700 mb-1">
                      Mobile Number (+91)
                    </label>
                    <input
                      type="tel"
                      required
                      maxLength={10}
                      value={applicantPhone}
                      onChange={(e) => setApplicantPhone(e.target.value.replace(/\D/g, ''))}
                      className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-slate-900 font-mono-numbers"
                      placeholder="9876543210"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-medium text-slate-700 mb-1">
                      Application Type / Sub-Category
                    </label>
                    <select
                      value={serviceFormType}
                      onChange={(e) => setServiceFormType(e.target.value)}
                      className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-slate-900 bg-white"
                    >
                      <option value="Fresh / New Application">Fresh / New Application</option>
                      <option value="Demographic / Spelling Correction">Demographic / Spelling Correction</option>
                      <option value="Address / Mobile Update">Address / Mobile Update</option>
                      <option value="Reprint / Lost Card Replacement">Reprint / Lost Card Replacement</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-slate-700 mb-1">
                      Aadhaar / Reference ID (Last 4 digits)
                    </label>
                    <input
                      type="text"
                      maxLength={4}
                      value={idNumber}
                      onChange={(e) => setIdNumber(e.target.value.replace(/\D/g, ''))}
                      className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-slate-900 font-mono-numbers"
                      placeholder="e.g. 7142"
                    />
                  </div>
                </div>

                {/* Secure Document Upload Zone */}
                <div>
                  <div className="flex items-center justify-between mb-1.5">
                    <label className="text-xs font-medium text-slate-700">
                      Upload Identity & Address Scans (PDF / JPG)
                    </label>
                    <span className="text-[11px] text-emerald-700 flex items-center gap-1">
                      <Lock className="w-3 h-3" />
                      Client-Side AES-256 Vault
                    </span>
                  </div>

                  <div className="border-2 border-dashed border-slate-200 rounded-xl p-4 text-center hover:border-slate-400 transition-colors bg-slate-50/50">
                    <input
                      type="file"
                      id="doc-upload"
                      multiple
                      accept=".pdf,.jpg,.jpeg,.png"
                      onChange={handleFileUpload}
                      className="hidden"
                    />
                    <label
                      htmlFor="doc-upload"
                      className="cursor-pointer flex flex-col items-center justify-center gap-1.5"
                    >
                      <Upload className="w-5 h-5 text-slate-500" />
                      <span className="text-xs font-semibold text-slate-800">
                        Click to browse documents or drag files here
                      </span>
                      <span className="text-[11px] text-slate-500">
                        Supported: Aadhaar front/back, Passport photo, Signature, Ration card (Max 10MB)
                      </span>
                    </label>
                  </div>

                  {/* Uploaded Files List */}
                  {uploadedFiles.length > 0 && (
                    <div className="mt-3 space-y-1.5">
                      {uploadedFiles.map((f, i) => (
                        <div
                          key={i}
                          className="flex items-center justify-between px-3 py-2 bg-slate-100 rounded-lg text-xs"
                        >
                          <div className="flex items-center gap-2 truncate">
                            <FileText className="w-4 h-4 text-slate-600 shrink-0" />
                            <span className="font-medium text-slate-800 truncate">{f.name}</span>
                            <span className="text-slate-400 font-mono-numbers text-[10px]">({f.size})</span>
                          </div>
                          <span className="font-mono-numbers text-[10px] text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded shrink-0">
                            {f.encryptedHash}
                          </span>
                        </div>
                      ))}
                    </div>
                  )}
                </div>

                {/* Price & Cancellation safety info */}
                <div className="p-3 bg-amber-50/80 border border-amber-200 rounded-lg text-amber-900 text-xs space-y-1">
                  <div className="flex items-center gap-1.5 font-semibold">
                    <AlertCircle className="w-4 h-4 text-amber-700 shrink-0" />
                    <span>Accidental Order Protection Active</span>
                  </div>
                  <p className="text-[11px] text-amber-800 leading-normal">
                    You can immediately cancel this order with an instant refund to your digital wallet at any time before the CSC operator begins portal form processing.
                  </p>
                </div>

                {/* Price Breakdown & Submission */}
                <div className="pt-3 border-t border-slate-200 flex items-center justify-between">
                  <div>
                    <span className="text-[11px] text-slate-500 block">Total Portal Fee</span>
                    <span className="text-lg font-bold text-slate-900 font-mono-numbers">
                      ₹{selectedService.basePrice}
                    </span>
                  </div>

                  <div className="flex gap-2">
                    <button
                      type="button"
                      onClick={() => setSelectedService(null)}
                      className="px-4 py-2 text-xs font-medium text-slate-700 border border-slate-300 rounded-lg hover:bg-slate-50 transition-colors"
                    >
                      Cancel
                    </button>
                    <button
                      type="submit"
                      disabled={isSubmitting}
                      className="px-5 py-2 text-xs font-semibold text-white bg-slate-900 rounded-lg hover:bg-slate-800 transition-colors disabled:opacity-50 flex items-center gap-1.5 cursor-pointer"
                    >
                      {isSubmitting ? 'Securing & Lodging...' : 'Lodge Application (₹' + selectedService.basePrice + ')'}
                    </button>
                  </div>
                </div>
              </form>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
