import React, { useState } from 'react';
import { Order, OrderStatus, ProductCategory, LedgerTransaction } from '../types';
import {
  CheckCircle2,
  AlertCircle,
  Clock,
  Printer,
  Upload,
  ArrowRight,
  ShieldCheck,
  FileCheck,
  Search,
  Filter,
  Check,
  Eye,
  Lock,
  ChevronRight,
  Sparkles,
  Layers,
  Wrench,
  FileText,
  Package,
  Truck,
  RotateCcw,
} from 'lucide-react';

interface AdminPipelineKanbanProps {
  orders: Order[];
  onUpdateOrderStatus: (
    orderId: string,
    newStatus: OrderStatus,
    adminProofUrl?: string,
    note?: string
  ) => void;
  onRecordPayment: (transaction: LedgerTransaction) => void;
  onViewInvoice: (order: Order) => void;
}

const PIPELINE_STAGES: {
  id: OrderStatus;
  stepNumber: number;
  label: string;
  desc: string;
  icon: React.ElementType;
  accentColor: string;
  headerBg: string;
}[] = [
  {
    id: 'order_received',
    stepNumber: 1,
    label: 'Order Received',
    desc: 'New entries · Cancel active',
    icon: Clock,
    accentColor: 'text-blue-600',
    headerBg: 'bg-blue-50/70 border-blue-200',
  },
  {
    id: 'designing',
    stepNumber: 2,
    label: 'Designing & Prep',
    desc: 'Pre-press & diagnostic',
    icon: Sparkles,
    accentColor: 'text-purple-600',
    headerBg: 'bg-purple-50/70 border-purple-200',
  },
  {
    id: 'awaiting_approval',
    stepNumber: 3,
    label: 'Awaiting Approval',
    desc: 'Customer sign-off gate',
    icon: FileCheck,
    accentColor: 'text-amber-600',
    headerBg: 'bg-amber-50 border-amber-200',
  },
  {
    id: 'advance_paid',
    stepNumber: 4,
    label: 'Advance Paid',
    desc: 'Deposit locked in ledger',
    icon: ShieldCheck,
    accentColor: 'text-indigo-600',
    headerBg: 'bg-indigo-50/70 border-indigo-200',
  },
  {
    id: 'printing',
    stepNumber: 5,
    label: 'Printing & Work',
    desc: 'Sublimation & hardware',
    icon: Printer,
    accentColor: 'text-cyan-600',
    headerBg: 'bg-cyan-50/70 border-cyan-200',
  },
  {
    id: 'quality_check',
    stepNumber: 6,
    label: 'Quality Check',
    desc: 'Checklist verification',
    icon: CheckCircle2,
    accentColor: 'text-orange-600',
    headerBg: 'bg-orange-50/70 border-orange-200',
  },
  {
    id: 'packing',
    stepNumber: 7,
    label: 'Packing & Invoicing',
    desc: 'Tax invoice sealed',
    icon: Package,
    accentColor: 'text-teal-600',
    headerBg: 'bg-teal-50/70 border-teal-200',
  },
  {
    id: 'ready_delivery',
    stepNumber: 8,
    label: 'Ready / Delivered',
    desc: 'Counter pickup & balance',
    icon: Truck,
    accentColor: 'text-emerald-600',
    headerBg: 'bg-emerald-50/70 border-emerald-200',
  },
];

export const AdminPipelineKanban: React.FC<AdminPipelineKanbanProps> = ({
  orders,
  onUpdateOrderStatus,
  onRecordPayment,
  onViewInvoice,
}) => {
  const [selectedVertical, setSelectedVertical] = useState<'all' | ProductCategory>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [highlightStage, setHighlightStage] = useState<OrderStatus | 'all'>('all');
  const [inspectingOrder, setInspectingOrder] = useState<Order | null>(null);

  // Inspector modal states
  const [adminProofInput, setAdminProofInput] = useState('');
  const [actionError, setActionError] = useState<string | null>(null);

  // Status Counts for Dashboard Summary Card
  const countByStatus: Record<OrderStatus, number> = {
    order_received: orders.filter((o) => o.orderStatus === 'order_received').length,
    designing: orders.filter((o) => o.orderStatus === 'designing').length,
    awaiting_approval: orders.filter((o) => o.orderStatus === 'awaiting_approval').length,
    advance_paid: orders.filter((o) => o.orderStatus === 'advance_paid').length,
    printing: orders.filter((o) => o.orderStatus === 'printing').length,
    quality_check: orders.filter((o) => o.orderStatus === 'quality_check').length,
    packing: orders.filter((o) => o.orderStatus === 'packing').length,
    ready_delivery: orders.filter((o) => o.orderStatus === 'ready_delivery').length,
    cancelled: orders.filter((o) => o.orderStatus === 'cancelled').length,
  };

  const totalActiveOrders = orders.filter(
    (o) => o.orderStatus !== 'ready_delivery' && o.orderStatus !== 'cancelled'
  ).length;

  const totalPipelineValue = orders.reduce((sum, o) => sum + o.totalPrice, 0);

  // Filter orders
  const filteredOrders = orders.filter((o) => {
    if (selectedVertical !== 'all' && o.category !== selectedVertical) return false;
    if (highlightStage !== 'all' && o.orderStatus !== highlightStage) return false;
    if (searchQuery) {
      const q = searchQuery.toLowerCase();
      return (
        o.orderId.toLowerCase().includes(q) ||
        o.customerName.toLowerCase().includes(q) ||
        o.productType.toLowerCase().includes(q) ||
        o.customerPhone.includes(q)
      );
    }
    return true;
  });

  const getOrdersByStage = (stage: OrderStatus) => {
    return filteredOrders.filter((o) => o.orderStatus === stage);
  };

  const handleOpenInspector = (order: Order) => {
    setInspectingOrder(order);
    setActionError(null);
    setAdminProofInput(order.adminDesignProofUrl || '');
  };

  // Quick 1-click stage advancer right from Kanban card
  const handleQuickAdvance = (order: Order, e: React.MouseEvent) => {
    e.stopPropagation();
    const currentIdx = PIPELINE_STAGES.findIndex((s) => s.id === order.orderStatus);
    if (currentIdx === -1 || currentIdx >= PIPELINE_STAGES.length - 1) return;

    const nextStage = PIPELINE_STAGES[currentIdx + 1].id;

    // Strict invariant check: cannot advance to printing if design is unapproved!
    if (
      nextStage === 'printing' &&
      order.category === 'printing' &&
      !order.customerDesignApproval.isApproved
    ) {
      handleOpenInspector(order);
      setActionError(
        'LEGAL GATE BLOCKED: Final printing is locked until customer reviews and approves the design proof.'
      );
      return;
    }

    onUpdateOrderStatus(
      order.id,
      nextStage,
      order.adminDesignProofUrl,
      `Quick advanced to ${nextStage} from Kanban strip`
    );

    if (nextStage === 'ready_delivery' && order.balanceRemaining > 0) {
      onRecordPayment({
        id: 'tx_' + Date.now(),
        orderId: order.orderId,
        category: order.category,
        customerName: order.customerName,
        type: 'balance',
        amount: order.balanceRemaining,
        paymentMethod: 'Cash at Counter',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        notes: `Balance cleared at delivery counter for ${order.orderId}`,
      });
    }
  };

  const handleAdvanceStage = (targetStage: OrderStatus) => {
    if (!inspectingOrder) return;

    if (
      targetStage === 'printing' &&
      inspectingOrder.category === 'printing' &&
      !inspectingOrder.customerDesignApproval.isApproved
    ) {
      setActionError(
        'LEGAL GATE ENFORCED: Final printing cannot unlock until the customer reviews the proof and clicks the legal design approval declaration.'
      );
      return;
    }

    onUpdateOrderStatus(
      inspectingOrder.id,
      targetStage,
      adminProofInput || inspectingOrder.adminDesignProofUrl,
      `Advanced to ${targetStage} by Admin Desk`
    );

    if (targetStage === 'ready_delivery' && inspectingOrder.balanceRemaining > 0) {
      onRecordPayment({
        id: 'tx_' + Date.now(),
        orderId: inspectingOrder.orderId,
        category: inspectingOrder.category,
        customerName: inspectingOrder.customerName,
        type: 'balance',
        amount: inspectingOrder.balanceRemaining,
        paymentMethod: 'Cash at Counter',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        notes: `Balance cleared at delivery counter for ${inspectingOrder.orderId}`,
      });
    }

    setInspectingOrder(null);
  };

  const getCategoryTheme = (cat: ProductCategory) => {
    switch (cat) {
      case 'printing':
        return {
          badge: 'bg-purple-100 text-purple-800 border-purple-200',
          bar: 'bg-purple-600',
          icon: Printer,
          label: 'Printing',
        };
      case 'mobile':
        return {
          badge: 'bg-blue-100 text-blue-800 border-blue-200',
          bar: 'bg-blue-600',
          icon: Wrench,
          label: 'Mobile',
        };
      case 'csc':
        return {
          badge: 'bg-emerald-100 text-emerald-800 border-emerald-200',
          bar: 'bg-emerald-600',
          icon: FileText,
          label: 'CSC Portal',
        };
    }
  };

  return (
    <div className="space-y-6">
      {/* =========================================================================
          1. DASHBOARD SUMMARY CARD (STATUS COUNTS & PIPELINE PULSE)
         ========================================================================= */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
        {/* Top Summary Bar */}
        <div className="p-5 border-b border-slate-100 flex flex-col md:flex-row md:items-center justify-between gap-4 bg-gradient-to-r from-slate-50 via-white to-slate-50">
          <div>
            <div className="flex items-center gap-2 text-xs text-slate-500 mb-1">
              <span>Operational Command</span>
              <span aria-hidden="true">·</span>
              <span>Live Order Pipeline</span>
              <span aria-hidden="true">·</span>
              <span className="font-mono-numbers font-medium text-slate-700">
                {orders.length} Total Registered Orders
              </span>
            </div>
            <h2 className="text-xl font-bold tracking-tight text-slate-900">
              Pipeline Stage Summary & Live Queue Metrics
            </h2>
          </div>

          <div className="flex items-center gap-3">
            <div className="text-right">
              <span className="text-[11px] text-slate-500 block">Total Pipeline Value</span>
              <span className="text-lg font-bold font-mono-numbers text-slate-900">
                ₹{totalPipelineValue.toLocaleString()}
              </span>
            </div>

            {highlightStage !== 'all' && (
              <button
                onClick={() => setHighlightStage('all')}
                className="px-3 py-1.5 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors cursor-pointer"
              >
                Clear Stage Filter
              </button>
            )}
          </div>
        </div>

        {/* Status Metrics Cards Grid */}
        <div className="p-4 grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-3 bg-slate-50/50">
          {PIPELINE_STAGES.map((st) => {
            const count = countByStatus[st.id] || 0;
            const isSelected = highlightStage === st.id;
            const Icon = st.icon;

            return (
              <div
                key={st.id}
                onClick={() => setHighlightStage(isSelected ? 'all' : st.id)}
                className={`p-3 rounded-xl border transition-all duration-200 cursor-pointer flex flex-col justify-between ${
                  isSelected
                    ? 'bg-slate-900 text-white border-slate-900 shadow-sm scale-102 ring-2 ring-slate-900/10'
                    : count > 0
                    ? 'bg-white hover:border-slate-400 border-slate-200 shadow-2xs hover:shadow-xs'
                    : 'bg-white/60 border-slate-200 text-slate-400 hover:bg-white'
                }`}
              >
                <div className="flex items-center justify-between mb-2">
                  <span
                    className={`text-[10px] font-mono font-bold ${
                      isSelected ? 'text-slate-300' : 'text-slate-400'
                    }`}
                  >
                    0{st.stepNumber}
                  </span>
                  <Icon
                    className={`w-3.5 h-3.5 ${
                      isSelected ? 'text-white' : st.accentColor
                    }`}
                  />
                </div>

                <div>
                  <div
                    className={`text-xl font-bold font-mono-numbers leading-tight ${
                      isSelected
                        ? 'text-white'
                        : count > 0
                        ? 'text-slate-900'
                        : 'text-slate-400'
                    }`}
                  >
                    {count}
                  </div>
                  <div
                    className={`text-[11px] font-semibold truncate mt-0.5 ${
                      isSelected ? 'text-slate-200' : 'text-slate-700'
                    }`}
                    title={st.label}
                  >
                    {st.label.replace(/^\d+\.\s*/, '')}
                  </div>
                </div>

                {st.id === 'awaiting_approval' && count > 0 && !isSelected && (
                  <span className="mt-1.5 inline-block text-[9px] font-bold text-amber-800 bg-amber-100 px-1.5 py-0.2 rounded text-center">
                    Action Needed
                  </span>
                )}
              </div>
            );
          })}
        </div>
      </div>

      {/* =========================================================================
          2. FILTER & SEARCH CONTROLS
         ========================================================================= */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-white p-3.5 rounded-xl border border-slate-200 shadow-2xs">
        <div className="flex flex-wrap items-center gap-2">
          <span className="text-xs font-semibold text-slate-700">Vertical Filter:</span>
          <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-lg">
            <button
              onClick={() => setSelectedVertical('all')}
              className={`px-3 py-1.5 text-xs font-medium rounded-md transition-all cursor-pointer ${
                selectedVertical === 'all'
                  ? 'bg-white text-slate-900 shadow-xs font-semibold'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              All Verticals ({orders.length})
            </button>
            <button
              onClick={() => setSelectedVertical('printing')}
              className={`px-3 py-1.5 text-xs font-medium rounded-md transition-all cursor-pointer flex items-center gap-1.5 ${
                selectedVertical === 'printing'
                  ? 'bg-white text-slate-900 shadow-xs font-semibold'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Printer className="w-3.5 h-3.5 text-purple-600" />
              <span>Custom Printing</span>
            </button>
            <button
              onClick={() => setSelectedVertical('mobile')}
              className={`px-3 py-1.5 text-xs font-medium rounded-md transition-all cursor-pointer flex items-center gap-1.5 ${
                selectedVertical === 'mobile'
                  ? 'bg-white text-slate-900 shadow-xs font-semibold'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Wrench className="w-3.5 h-3.5 text-blue-600" />
              <span>Mobile Repair</span>
            </button>
            <button
              onClick={() => setSelectedVertical('csc')}
              className={`px-3 py-1.5 text-xs font-medium rounded-md transition-all cursor-pointer flex items-center gap-1.5 ${
                selectedVertical === 'csc'
                  ? 'bg-white text-slate-900 shadow-xs font-semibold'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <FileText className="w-3.5 h-3.5 text-emerald-600" />
              <span>CSC Digital</span>
            </button>
          </div>
        </div>

        {/* Search */}
        <div className="relative w-full md:w-80">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search Order ID, Customer, Phone..."
            className="w-full pl-9 pr-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-slate-900 bg-white"
          />
        </div>
      </div>

      {/* =========================================================================
          3. SMOOTH 8-STAGE WORKFLOW KANBAN BOARD
         ========================================================================= */}
      <div className="overflow-x-auto pb-4">
        <div className="flex gap-4 min-w-[1520px]">
          {PIPELINE_STAGES.map((stage) => {
            const stageOrders = getOrdersByStage(stage.id);
            const isColumnFiltered = highlightStage === stage.id;
            const StageIcon = stage.icon;

            return (
              <div
                key={stage.id}
                className={`w-84 shrink-0 rounded-2xl border transition-all duration-200 flex flex-col max-h-[780px] ${
                  isColumnFiltered
                    ? 'ring-2 ring-slate-900 bg-slate-100/90 shadow-md'
                    : 'bg-slate-100/70 border-slate-200'
                }`}
              >
                {/* Column Header */}
                <div
                  className={`p-3.5 border-b rounded-t-2xl transition-colors ${stage.headerBg}`}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <div className="w-6 h-6 rounded-lg bg-white/90 shadow-2xs flex items-center justify-center">
                        <StageIcon className={`w-3.5 h-3.5 ${stage.accentColor}`} />
                      </div>
                      <h3 className="text-xs font-bold text-slate-900">
                        {stage.label}
                      </h3>
                    </div>
                    <span className="font-mono-numbers text-xs font-bold bg-white text-slate-800 px-2 py-0.5 rounded-md shadow-2xs border border-slate-200/60">
                      {stageOrders.length}
                    </span>
                  </div>
                  <p className="text-[10px] text-slate-500 mt-1 pl-8">{stage.desc}</p>
                </div>

                {/* Cards Container */}
                <div className="p-3 space-y-3 overflow-y-auto flex-1">
                  {stageOrders.length === 0 ? (
                    <div className="p-8 text-center text-xs text-slate-400 border border-dashed border-slate-200 rounded-xl bg-white/50 flex flex-col items-center justify-center gap-1">
                      <StageIcon className="w-5 h-5 text-slate-300 mb-1" />
                      <span>No orders at this stage</span>
                    </div>
                  ) : (
                    stageOrders.map((order) => {
                      const theme = getCategoryTheme(order.category);
                      const isWaitingApproval =
                        order.orderStatus === 'awaiting_approval' &&
                        !order.customerDesignApproval.isApproved;
                      const stageIdx = PIPELINE_STAGES.findIndex(
                        (s) => s.id === order.orderStatus
                      );
                      const progressPercent = Math.round(
                        ((stageIdx + 1) / PIPELINE_STAGES.length) * 100
                      );

                      return (
                        <div
                          key={order.id}
                          onClick={() => handleOpenInspector(order)}
                          className="group bg-white rounded-xl border border-slate-200 p-4 shadow-2xs hover:shadow-md hover:border-slate-400 transition-all duration-200 cursor-pointer space-y-3 relative"
                        >
                          {/* Card Header */}
                          <div className="flex items-center justify-between">
                            <div className="flex items-center gap-2">
                              <span className="font-mono-numbers font-bold text-xs text-slate-900">
                                {order.orderId}
                              </span>
                              <span
                                className={`text-[10px] font-semibold px-2 py-0.5 rounded-md border ${theme.badge}`}
                              >
                                {theme.label}
                              </span>
                            </div>

                            <span className="text-[10px] text-slate-400 font-mono-numbers">
                              {new Date(order.createdAt).toLocaleDateString([], {
                                month: 'short',
                                day: 'numeric',
                              })}
                            </span>
                          </div>

                          {/* Product & Customer Details */}
                          <div>
                            <h4 className="text-xs font-bold text-slate-900 leading-snug line-clamp-2">
                              {order.productType}
                            </h4>
                            <p className="text-[11px] text-slate-500 mt-0.5">
                              {order.customerName} · +91 {order.customerPhone.slice(-4)}
                            </p>
                          </div>

                          {/* Order Stage Progress Bar */}
                          <div className="space-y-1">
                            <div className="flex justify-between text-[10px] text-slate-400 font-mono-numbers">
                              <span>Pipeline Progress</span>
                              <span>{stageIdx + 1}/8 Stages</span>
                            </div>
                            <div className="w-full h-1.5 bg-slate-100 rounded-full overflow-hidden">
                              <div
                                className={`h-full transition-all duration-300 ${theme.bar}`}
                                style={{ width: `${progressPercent}%` }}
                              />
                            </div>
                          </div>

                          {/* Conditional Alerts */}
                          {isWaitingApproval && (
                            <div className="p-2 bg-amber-50 border border-amber-200 rounded-lg text-[10px] text-amber-900 font-semibold flex items-center gap-1.5 animate-pulse">
                              <Lock className="w-3.5 h-3.5 text-amber-700 shrink-0" />
                              <span>Customer Design Sign-Off Required</span>
                            </div>
                          )}

                          {order.customerDesignApproval.isApproved && (
                            <div className="p-1.5 bg-emerald-50 border border-emerald-200 rounded-md text-[10px] text-emerald-800 font-medium flex items-center gap-1">
                              <CheckCircle2 className="w-3 h-3 text-emerald-600 shrink-0" />
                              <span>Design Legally Approved</span>
                            </div>
                          )}

                          {order.orderStatus === 'order_received' && order.canCancel && (
                            <div className="text-[10px] text-blue-700 bg-blue-50 px-2 py-1 rounded-md border border-blue-100">
                              Accidental cancellation active
                            </div>
                          )}

                          {/* Footer with Financials & 1-Click Quick Advance Action */}
                          <div className="flex items-center justify-between text-[11px] pt-2 border-t border-slate-100">
                            <div>
                              <span className="text-slate-400 text-[10px] block">Total</span>
                              <span className="font-mono-numbers font-bold text-slate-900">
                                ₹{order.totalPrice}
                              </span>
                            </div>

                            <div className="flex items-center gap-1.5">
                              {stageIdx < PIPELINE_STAGES.length - 1 && (
                                <button
                                  type="button"
                                  onClick={(e) => handleQuickAdvance(order, e)}
                                  className="px-2 py-1 bg-slate-900 hover:bg-slate-800 text-white text-[10px] font-semibold rounded-md transition-colors flex items-center gap-1 cursor-pointer"
                                  title={`Advance to ${PIPELINE_STAGES[stageIdx + 1]?.label}`}
                                >
                                  <span>Advance</span>
                                  <ChevronRight className="w-3 h-3" />
                                </button>
                              )}
                            </div>
                          </div>
                        </div>
                      );
                    })
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* =========================================================================
          4. ADMIN ORDER INSPECTION & STAGE ADVANCER MODAL
         ========================================================================= */}
      {inspectingOrder && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/70 backdrop-blur-xs p-4 overflow-y-auto">
          <div className="w-full max-w-2xl bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden my-8 animate-in fade-in zoom-in-95">
            <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 bg-slate-50/70">
              <div>
                <h3 className="text-base font-bold text-slate-900">
                  Order Management Console · {inspectingOrder.orderId}
                </h3>
                <p className="text-xs text-slate-500">
                  {inspectingOrder.category.toUpperCase()} · Customer: {inspectingOrder.customerName} (+91 {inspectingOrder.customerPhone})
                </p>
              </div>
              <button
                onClick={() => setInspectingOrder(null)}
                className="text-slate-400 hover:text-slate-700 text-sm font-bold p-1 cursor-pointer"
              >
                ✕
              </button>
            </div>

            <div className="p-6 space-y-6">
              {/* Error Notice */}
              {actionError && (
                <div className="p-3.5 bg-rose-50 border border-rose-300 rounded-xl text-rose-800 text-xs flex items-start gap-2">
                  <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
                  <span>{actionError}</span>
                </div>
              )}

              {/* Order summary info */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 bg-slate-50 p-4 rounded-xl border border-slate-200 text-xs">
                <div>
                  <span className="text-slate-500 block">Current Stage:</span>
                  <span className="font-bold text-slate-900 capitalize">
                    {inspectingOrder.orderStatus.replace('_', ' ')}
                  </span>
                </div>
                <div>
                  <span className="text-slate-500 block">Total Price:</span>
                  <span className="font-mono-numbers font-bold text-slate-900">
                    ₹{inspectingOrder.totalPrice}
                  </span>
                </div>
                <div>
                  <span className="text-slate-500 block">Advance Collected:</span>
                  <span className="font-mono-numbers font-bold text-emerald-700">
                    ₹{inspectingOrder.advancePaid}
                  </span>
                </div>
                <div>
                  <span className="text-slate-500 block">Balance Due:</span>
                  <span className="font-mono-numbers font-bold text-slate-800">
                    ₹{inspectingOrder.balanceRemaining}
                  </span>
                </div>
              </div>

              {/* Upload Design Proof */}
              <div className="space-y-3 pt-3 border-t border-slate-100">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-bold text-slate-900 flex items-center gap-1.5">
                    <Upload className="w-4 h-4 text-slate-600" />
                    Attach Studio Production Proof (URL):
                  </label>
                  {inspectingOrder.customerDesignApproval.isApproved ? (
                    <span className="text-[11px] text-emerald-700 font-semibold flex items-center gap-1">
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      Approved by Customer
                    </span>
                  ) : (
                    <span className="text-[11px] text-amber-700 font-semibold">
                      Unapproved
                    </span>
                  )}
                </div>

                <div className="flex gap-2">
                  <input
                    type="url"
                    value={adminProofInput}
                    onChange={(e) => setAdminProofInput(e.target.value)}
                    placeholder="https://images.unsplash.com/photo-1503342217505-b0a15ec3261c..."
                    className="flex-1 px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-slate-900 font-mono-numbers"
                  />
                  <button
                    type="button"
                    onClick={() => {
                      onUpdateOrderStatus(
                        inspectingOrder.id,
                        'awaiting_approval',
                        adminProofInput,
                        'Admin uploaded calibrated production proof'
                      );
                      setInspectingOrder(null);
                    }}
                    className="px-4 py-2 text-xs font-semibold text-white bg-slate-900 rounded-lg hover:bg-slate-800 transition-colors cursor-pointer"
                  >
                    Send to Customer
                  </button>
                </div>
                <p className="text-[11px] text-slate-500">
                  Sending proof shifts the order into "Awaiting Customer Approval" and immediately locks the accidental cancellation window.
                </p>
              </div>

              {/* Advance to Next Stage Button Bar */}
              <div className="space-y-2 pt-3 border-t border-slate-100">
                <span className="text-xs font-bold text-slate-900 block">
                  Advance Operational Pipeline:
                </span>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                  {PIPELINE_STAGES.slice(1).map((stage) => (
                    <button
                      key={stage.id}
                      type="button"
                      onClick={() => handleAdvanceStage(stage.id)}
                      className={`p-2.5 text-xs font-semibold rounded-lg border text-center transition-colors cursor-pointer ${
                        stage.id === 'ready_delivery'
                          ? 'border-emerald-300 bg-emerald-50 text-emerald-800 hover:bg-emerald-100 font-bold'
                          : 'border-slate-300 hover:bg-slate-50 text-slate-800'
                      }`}
                    >
                      → {stage.label.replace(/^\d+\.\s*/, '')}
                    </button>
                  ))}
                </div>
              </div>

              {/* Footer actions */}
              <div className="flex items-center justify-between pt-4 border-t border-slate-200">
                <button
                  type="button"
                  onClick={() => onViewInvoice(inspectingOrder)}
                  className="px-3.5 py-2 text-xs font-medium text-slate-700 border border-slate-300 rounded-lg hover:bg-slate-50 cursor-pointer"
                >
                  Print Job Sheet / Invoice
                </button>
                <button
                  type="button"
                  onClick={() => setInspectingOrder(null)}
                  className="px-4 py-2 text-xs font-semibold text-slate-900 border border-slate-300 rounded-lg hover:bg-slate-100 cursor-pointer"
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
