import React, { useState } from 'react';
import { BLUEPRINT_DATA } from '../data/blueprintData';
import {
  Database,
  Server,
  Shield,
  Layers,
  Copy,
  Check,
  Code2,
  FileText,
  Lock,
  ArrowRight,
  Workflow,
  Sparkles,
} from 'lucide-react';

export const BlueprintView: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'schema' | 'api' | 'security' | 'stack' | 'workflow'>('schema');
  const [copiedSql, setCopiedSql] = useState(false);

  const handleCopySql = () => {
    navigator.clipboard.writeText(BLUEPRINT_DATA.dbSchemaSql);
    setCopiedSql(true);
    setTimeout(() => setCopiedSql(false), 2000);
  };

  return (
    <div className="space-y-8">
      {/* Blueprint Header */}
      <div className="bg-white rounded-xl border border-slate-200 p-6 sm:p-8 space-y-3">
        <div className="flex items-center gap-2 text-xs text-slate-500">
          <span>Software Architecture Blueprint</span>
          <span aria-hidden="true">·</span>
          <span>{BLUEPRINT_DATA.overview.version}</span>
          <span aria-hidden="true">·</span>
          <span>Ready-To-Implement Specifications</span>
        </div>

        <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-slate-900">
          {BLUEPRINT_DATA.overview.title}
        </h1>

        <p className="text-sm text-slate-600 leading-relaxed max-w-3xl">
          {BLUEPRINT_DATA.overview.summary}
        </p>

        {/* Tab Controls */}
        <div className="flex flex-wrap gap-2 pt-4 border-t border-slate-100">
          <button
            onClick={() => setActiveTab('schema')}
            className={`px-3.5 py-1.5 text-xs font-semibold rounded-lg border transition-colors cursor-pointer flex items-center gap-1.5 ${
              activeTab === 'schema'
                ? 'bg-slate-900 text-white border-slate-900'
                : 'bg-slate-50 text-slate-700 border-slate-200 hover:border-slate-300'
            }`}
          >
            <Database className="w-3.5 h-3.5" />
            1. PostgreSQL Relational Schema
          </button>

          <button
            onClick={() => setActiveTab('api')}
            className={`px-3.5 py-1.5 text-xs font-semibold rounded-lg border transition-colors cursor-pointer flex items-center gap-1.5 ${
              activeTab === 'api'
                ? 'bg-slate-900 text-white border-slate-900'
                : 'bg-slate-50 text-slate-700 border-slate-200 hover:border-slate-300'
            }`}
          >
            <Server className="w-3.5 h-3.5" />
            2. REST & RPC API Logic
          </button>

          <button
            onClick={() => setActiveTab('security')}
            className={`px-3.5 py-1.5 text-xs font-semibold rounded-lg border transition-colors cursor-pointer flex items-center gap-1.5 ${
              activeTab === 'security'
                ? 'bg-slate-900 text-white border-slate-900'
                : 'bg-slate-50 text-slate-700 border-slate-200 hover:border-slate-300'
            }`}
          >
            <Shield className="w-3.5 h-3.5" />
            3. Security & Govt Doc Vault
          </button>

          <button
            onClick={() => setActiveTab('workflow')}
            className={`px-3.5 py-1.5 text-xs font-semibold rounded-lg border transition-colors cursor-pointer flex items-center gap-1.5 ${
              activeTab === 'workflow'
                ? 'bg-slate-900 text-white border-slate-900'
                : 'bg-slate-50 text-slate-700 border-slate-200 hover:border-slate-300'
            }`}
          >
            <Workflow className="w-3.5 h-3.5" />
            4. 8-Stage Pipeline Invariants
          </button>

          <button
            onClick={() => setActiveTab('stack')}
            className={`px-3.5 py-1.5 text-xs font-semibold rounded-lg border transition-colors cursor-pointer flex items-center gap-1.5 ${
              activeTab === 'stack'
                ? 'bg-slate-900 text-white border-slate-900'
                : 'bg-slate-50 text-slate-700 border-slate-200 hover:border-slate-300'
            }`}
          >
            <Layers className="w-3.5 h-3.5" />
            5. Tech Stack & Production Guide
          </button>
        </div>
      </div>

      {/* TAB 1: POSTGRESQL RELATIONAL SCHEMA */}
      {activeTab === 'schema' && (
        <div className="bg-white rounded-xl border border-slate-200 overflow-hidden space-y-4">
          <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 bg-slate-50">
            <div>
              <h2 className="text-base font-bold text-slate-900">
                Relational Database DDL & Auto-Generating Order Code Trigger
              </h2>
              <p className="text-xs text-slate-500">
                Includes sequence generator, customer design approval gates, financial generated columns, and indexes
              </p>
            </div>
            <button
              onClick={handleCopySql}
              className="px-3 py-1.5 text-xs font-semibold text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-50 transition-colors flex items-center gap-1.5 cursor-pointer"
            >
              {copiedSql ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copiedSql ? 'Copied DDL!' : 'Copy SQL Schema'}</span>
            </button>
          </div>

          <div className="p-6">
            <pre className="p-4 bg-slate-950 text-slate-100 rounded-xl overflow-x-auto text-xs font-mono leading-relaxed border border-slate-800">
              <code>{BLUEPRINT_DATA.dbSchemaSql}</code>
            </pre>
          </div>
        </div>
      )}

      {/* TAB 2: REST & RPC API LOGIC */}
      {activeTab === 'api' && (
        <div className="space-y-4">
          <div className="bg-white p-4 rounded-xl border border-slate-200">
            <h2 className="text-base font-bold text-slate-900">API Contract & Endpoint Specifications</h2>
            <p className="text-xs text-slate-500">
              Covers OTP authentication, the Accidental Purchase Safety cancellation guard, Customer Design Approval Gate, and stage transitions.
            </p>
          </div>

          <div className="space-y-4">
            {BLUEPRINT_DATA.apiSpecs.map((spec, i) => (
              <div
                key={i}
                className="bg-white rounded-xl border border-slate-200 p-5 space-y-3"
              >
                <div className="flex flex-wrap items-center justify-between gap-2 pb-2 border-b border-slate-100">
                  <div className="flex items-center gap-2">
                    <span
                      className={`px-2 py-0.5 rounded text-[10px] font-bold font-mono ${
                        spec.method === 'POST'
                          ? 'bg-blue-100 text-blue-800'
                          : spec.method === 'GET'
                          ? 'bg-emerald-100 text-emerald-800'
                          : 'bg-amber-100 text-amber-800'
                      }`}
                    >
                      {spec.method}
                    </span>
                    <span className="font-mono text-xs font-bold text-slate-900">
                      {spec.endpoint}
                    </span>
                  </div>
                  <span className="text-xs text-slate-500 font-medium">
                    Auth: <span className="font-semibold text-slate-700">{spec.auth}</span>
                  </span>
                </div>

                <p className="text-xs text-slate-600 leading-relaxed">
                  {spec.description}
                </p>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2">
                  <div>
                    <span className="text-[10px] font-bold uppercase tracking-wider text-slate-500 block mb-1">
                      Request Payload:
                    </span>
                    <pre className="p-3 bg-slate-900 text-slate-200 rounded-lg text-[11px] font-mono overflow-x-auto">
                      <code>{spec.requestPayload}</code>
                    </pre>
                  </div>
                  <div>
                    <span className="text-[10px] font-bold uppercase tracking-wider text-slate-500 block mb-1">
                      Response Payload:
                    </span>
                    <pre className="p-3 bg-slate-900 text-emerald-400 rounded-lg text-[11px] font-mono overflow-x-auto">
                      <code>{spec.responsePayload}</code>
                    </pre>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 3: SECURITY & GOVT DOC VAULT */}
      {activeTab === 'security' && (
        <div className="space-y-6">
          {/* CSC Doc Vault */}
          <div className="bg-white rounded-xl border border-slate-200 p-6 space-y-4">
            <div className="flex items-center gap-2 text-slate-900 font-bold text-base">
              <Shield className="w-5 h-5 text-emerald-600" />
              <h2>{BLUEPRINT_DATA.securityArchitecture.cscGovtDocVault.title}</h2>
            </div>
            <p className="text-xs text-slate-600 leading-relaxed">
              Handling citizen identity documents (Aadhaar cards, PAN copies, caste certificates) requires stringent compliance with India's Digital Personal Data Protection Act (DPDPA 2023) and UIDAI circulars:
            </p>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2">
              {BLUEPRINT_DATA.securityArchitecture.cscGovtDocVault.protocols.map((p, idx) => (
                <div
                  key={idx}
                  className="p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-1.5"
                >
                  <div className="flex items-center gap-2">
                    <span className="w-5 h-5 rounded-full bg-emerald-100 text-emerald-800 text-[11px] font-bold flex items-center justify-center shrink-0">
                      {idx + 1}
                    </span>
                    <h3 className="text-xs font-bold text-slate-900">{p.layer}</h3>
                  </div>
                  <p className="text-xs text-slate-600 leading-relaxed pl-7">
                    {p.details}
                  </p>
                </div>
              ))}
            </div>
          </div>

          {/* Mobile Repair Privacy */}
          <div className="bg-white rounded-xl border border-slate-200 p-6 space-y-4">
            <div className="flex items-center gap-2 text-slate-900 font-bold text-base">
              <Lock className="w-5 h-5 text-indigo-600" />
              <h2>{BLUEPRINT_DATA.securityArchitecture.mobileCustomerPrivacy.title}</h2>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {BLUEPRINT_DATA.securityArchitecture.mobileCustomerPrivacy.protocols.map((p, idx) => (
                <div
                  key={idx}
                  className="p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-1"
                >
                  <h3 className="text-xs font-bold text-slate-900">{p.layer}</h3>
                  <p className="text-xs text-slate-600 leading-relaxed">{p.details}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* TAB 4: 8-STAGE WORKFLOW PIPELINE */}
      {activeTab === 'workflow' && (
        <div className="bg-white rounded-xl border border-slate-200 p-6 space-y-6">
          <div>
            <h2 className="text-base font-bold text-slate-900">
              Operational 8-Stage State Machine & Validation Invariants
            </h2>
            <p className="text-xs text-slate-500">
              Strict sequence progression: Order → Design → Customer Approval → Payment/Advance → Printing → Quality Check → Packing → Delivery
            </p>
          </div>

          <div className="space-y-4">
            {BLUEPRINT_DATA.operationalWorkflowRules.map((rule) => (
              <div
                key={rule.step}
                className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 p-4 rounded-xl border border-slate-200 bg-slate-50/50"
              >
                <div className="flex items-start sm:items-center gap-3">
                  <div className="w-8 h-8 rounded-lg bg-slate-900 text-white text-xs font-bold flex items-center justify-center shrink-0 font-mono">
                    0{rule.step}
                  </div>
                  <div>
                    <h3 className="text-xs font-bold text-slate-900">{rule.name}</h3>
                    <p className="text-xs text-slate-600 leading-normal max-w-xl">
                      {rule.description}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-3 shrink-0 text-xs">
                  <span className="text-slate-500">
                    Actor: <span className="font-semibold text-slate-800">{rule.actor}</span>
                  </span>
                  <span
                    className={`px-2.5 py-1 rounded text-[11px] font-semibold border ${
                      rule.cancellationActive
                        ? 'bg-blue-50 text-blue-700 border-blue-200'
                        : 'bg-slate-100 text-slate-600 border-slate-200'
                    }`}
                  >
                    {rule.cancellationActive ? 'Cancellation Open' : 'Cancellation Locked'}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 5: TECH STACK & PRODUCTION GUIDE */}
      {activeTab === 'stack' && (
        <div className="space-y-6">
          <div className="bg-white rounded-xl border border-slate-200 p-6 space-y-4">
            <div>
              <h2 className="text-base font-bold text-slate-900">Recommended Enterprise Tech Stack</h2>
              <p className="text-xs text-slate-500">
                Engineered for maximum velocity, rural/low-bandwidth resilience, and zero database inconsistency.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {BLUEPRINT_DATA.techStack.map((item, idx) => (
                <div
                  key={idx}
                  className="p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-1.5"
                >
                  <span className="text-[10px] font-bold uppercase tracking-wider text-slate-500">
                    {item.category}
                  </span>
                  <h3 className="text-sm font-bold text-slate-900">{item.technology}</h3>
                  <p className="text-xs text-slate-600 leading-relaxed">{item.rationale}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
