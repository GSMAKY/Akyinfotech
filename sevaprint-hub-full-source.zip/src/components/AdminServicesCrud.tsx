import React, { useState } from 'react';
import { ServiceItem, ProductCategory } from '../types';
import { Plus, Edit2, Trash2, Power, Check, X, Shield, Clock, IndianRupee } from 'lucide-react';

interface AdminServicesCrudProps {
  services: ServiceItem[];
  onAddService: (newService: ServiceItem) => void;
  onUpdateService: (updatedService: ServiceItem) => void;
  onDeleteService: (serviceId: string) => void;
}

export const AdminServicesCrud: React.FC<AdminServicesCrudProps> = ({
  services,
  onAddService,
  onUpdateService,
  onDeleteService,
}) => {
  const [activeCategory, setActiveCategory] = useState<'all' | ProductCategory>('all');
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [editingServiceId, setEditingServiceId] = useState<string | null>(null);
  const [editPriceValue, setEditPriceValue] = useState<number>(0);

  // New Service Form States
  const [newCategory, setNewCategory] = useState<ProductCategory>('printing');
  const [newTitle, setNewTitle] = useState('');
  const [newDescription, setNewDescription] = useState('');
  const [newPrice, setNewPrice] = useState(299);
  const [newTurnaround, setNewTurnaround] = useState(24);
  const [newDocs, setNewDocs] = useState('');

  const filteredServices = services.filter((s) =>
    activeCategory === 'all' ? true : s.category === activeCategory
  );

  const handleStartEditPrice = (s: ServiceItem) => {
    setEditingServiceId(s.id);
    setEditPriceValue(s.basePrice);
  };

  const handleSavePrice = (s: ServiceItem) => {
    onUpdateService({
      ...s,
      basePrice: Number(editPriceValue),
    });
    setEditingServiceId(null);
  };

  const handleToggleActive = (s: ServiceItem) => {
    onUpdateService({
      ...s,
      isActive: !s.isActive,
    });
  };

  const handleCreateNewService = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim()) return;

    const created: ServiceItem = {
      id: 'srv_dyn_' + Date.now().toString().slice(-6),
      category: newCategory,
      title: newTitle.trim(),
      description: newDescription.trim(),
      basePrice: Number(newPrice),
      turnaroundHours: Number(newTurnaround),
      isActive: true,
      requiredDocs: newDocs ? newDocs.split(',').map((d) => d.trim()).filter(Boolean) : undefined,
    };

    onAddService(created);
    setIsAddModalOpen(false);
    // Reset form
    setNewTitle('');
    setNewDescription('');
    setNewPrice(299);
    setNewTurnaround(24);
    setNewDocs('');
  };

  return (
    <div className="space-y-6">
      {/* Header & Controls */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-4 rounded-xl border border-slate-200">
        <div>
          <h2 className="text-base font-bold text-slate-900">Dynamic Service Catalog Management (CRUD)</h2>
          <p className="text-xs text-slate-500">
            Instant live modifications: Add new seasonal products, update tariff prices, or toggle deprecated services without code changes.
          </p>
        </div>

        <button
          onClick={() => setIsAddModalOpen(true)}
          className="px-4 py-2 text-xs font-semibold text-white bg-slate-900 rounded-lg hover:bg-slate-800 transition-colors flex items-center gap-1.5 shrink-0 cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          <span>Add New Service / Product</span>
        </button>
      </div>

      {/* Filter Tabs */}
      <div className="flex items-center gap-1.5 bg-slate-100 p-1 rounded-lg w-fit">
        <button
          onClick={() => setActiveCategory('all')}
          className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors cursor-pointer ${
            activeCategory === 'all' ? 'bg-white text-slate-900 shadow-xs font-semibold' : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          All Offerings ({services.length})
        </button>
        <button
          onClick={() => setActiveCategory('printing')}
          className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors cursor-pointer ${
            activeCategory === 'printing' ? 'bg-white text-slate-900 shadow-xs font-semibold' : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          Custom Printing ({services.filter((s) => s.category === 'printing').length})
        </button>
        <button
          onClick={() => setActiveCategory('mobile')}
          className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors cursor-pointer ${
            activeCategory === 'mobile' ? 'bg-white text-slate-900 shadow-xs font-semibold' : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          Mobile Repair ({services.filter((s) => s.category === 'mobile').length})
        </button>
        <button
          onClick={() => setActiveCategory('csc')}
          className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors cursor-pointer ${
            activeCategory === 'csc' ? 'bg-white text-slate-900 shadow-xs font-semibold' : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          CSC Portals ({services.filter((s) => s.category === 'csc').length})
        </button>
      </div>

      {/* Services Table */}
      <div className="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-2xs">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 text-slate-700 font-semibold border-b border-slate-200">
              <tr>
                <th className="py-3 px-4">Service / Product Title</th>
                <th className="py-3 px-4">Vertical</th>
                <th className="py-3 px-4 text-right">Base Price (₹)</th>
                <th className="py-3 px-4 text-center">Turnaround</th>
                <th className="py-3 px-4 text-center">Status</th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredServices.map((service) => {
                const isEditingThisPrice = editingServiceId === service.id;

                return (
                  <tr
                    key={service.id}
                    className={`hover:bg-slate-50/70 transition-colors ${
                      !service.isActive ? 'opacity-60 bg-slate-50/40' : ''
                    }`}
                  >
                    <td className="py-3.5 px-4">
                      <div className="font-bold text-slate-900">{service.title}</div>
                      <div className="text-[11px] text-slate-500 line-clamp-1 max-w-md">
                        {service.description}
                      </div>
                      {service.requiredDocs && (
                        <div className="text-[10px] text-slate-400 mt-0.5">
                          Docs: {service.requiredDocs.join(', ')}
                        </div>
                      )}
                    </td>

                    <td className="py-3.5 px-4">
                      <span className="text-[10px] font-semibold uppercase tracking-wider text-slate-600 bg-slate-100 px-2 py-0.5 rounded">
                        {service.category}
                      </span>
                    </td>

                    <td className="py-3.5 px-4 text-right font-mono-numbers">
                      {isEditingThisPrice ? (
                        <div className="flex items-center justify-end gap-1">
                          <input
                            type="number"
                            value={editPriceValue}
                            onChange={(e) => setEditPriceValue(Number(e.target.value))}
                            className="w-20 px-1.5 py-1 text-xs border border-slate-400 rounded text-right font-bold"
                          />
                          <button
                            onClick={() => handleSavePrice(service)}
                            className="p-1 text-emerald-600 hover:text-emerald-800"
                            title="Save"
                          >
                            <Check className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => setEditingServiceId(null)}
                            className="p-1 text-slate-400 hover:text-slate-600"
                            title="Cancel"
                          >
                            <X className="w-4 h-4" />
                          </button>
                        </div>
                      ) : (
                        <div className="flex items-center justify-end gap-1.5 group">
                          <span className="font-bold text-slate-900 text-sm">
                            ₹{service.basePrice}
                          </span>
                          <button
                            onClick={() => handleStartEditPrice(service)}
                            className="opacity-0 group-hover:opacity-100 text-slate-400 hover:text-slate-700 transition-opacity p-0.5"
                            title="Edit Price"
                          >
                            <Edit2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      )}
                    </td>

                    <td className="py-3.5 px-4 text-center font-mono-numbers text-slate-600">
                      {service.turnaroundHours}h
                    </td>

                    <td className="py-3.5 px-4 text-center">
                      <button
                        onClick={() => handleToggleActive(service)}
                        className={`px-2.5 py-0.5 text-[11px] rounded font-semibold transition-colors cursor-pointer ${
                          service.isActive
                            ? 'bg-emerald-50 text-emerald-700 hover:bg-emerald-100'
                            : 'bg-slate-200 text-slate-600 hover:bg-slate-300'
                        }`}
                      >
                        {service.isActive ? 'Live' : 'Disabled'}
                      </button>
                    </td>

                    <td className="py-3.5 px-4 text-right">
                      <div className="flex items-center justify-end gap-2">
                        <button
                          onClick={() => handleToggleActive(service)}
                          className="p-1 text-slate-500 hover:text-slate-800 transition-colors"
                          title={service.isActive ? 'Disable Service' : 'Enable Service'}
                        >
                          <Power className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => onDeleteService(service.id)}
                          className="p-1 text-rose-500 hover:text-rose-700 transition-colors"
                          title="Delete Service"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* ADD NEW SERVICE MODAL */}
      {isAddModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 backdrop-blur-xs p-4">
          <div className="w-full max-w-lg bg-white rounded-xl shadow-2xl border border-slate-200 overflow-hidden">
            <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 bg-slate-50">
              <h3 className="text-base font-bold text-slate-900">Add New Service to Catalog</h3>
              <button
                onClick={() => setIsAddModalOpen(false)}
                className="text-slate-400 hover:text-slate-700 p-1"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleCreateNewService} className="p-6 space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Vertical Category</label>
                <select
                  value={newCategory}
                  onChange={(e) => setNewCategory(e.target.value as ProductCategory)}
                  className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-slate-900 bg-white"
                >
                  <option value="printing">Custom Printing Hub</option>
                  <option value="mobile">Mobile Repair Hub</option>
                  <option value="csc">CSC / Digital Citizen Services</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Service / Product Title</label>
                <input
                  type="text"
                  required
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  placeholder="e.g. Seasonal Hoodies (350 GSM) or Aadhaar PVC Card"
                  className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-slate-900"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Description</label>
                <textarea
                  rows={2}
                  value={newDescription}
                  onChange={(e) => setNewDescription(e.target.value)}
                  placeholder="Brief specifications, warranty or requirements..."
                  className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-slate-900"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Base Price (₹)</label>
                  <input
                    type="number"
                    required
                    min={1}
                    value={newPrice}
                    onChange={(e) => setNewPrice(Number(e.target.value))}
                    className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-slate-900 font-mono-numbers"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Turnaround (Hours)</label>
                  <input
                    type="number"
                    required
                    min={1}
                    value={newTurnaround}
                    onChange={(e) => setNewTurnaround(Number(e.target.value))}
                    className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-slate-900 font-mono-numbers"
                  />
                </div>
              </div>

              {newCategory === 'csc' && (
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Required Citizen Documents (Comma-separated)
                  </label>
                  <input
                    type="text"
                    value={newDocs}
                    onChange={(e) => setNewDocs(e.target.value)}
                    placeholder="Aadhaar Card, Passport Photo, Electricity Bill"
                    className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-slate-900"
                  />
                </div>
              )}

              <div className="flex justify-end gap-2 pt-3 border-t border-slate-200">
                <button
                  type="button"
                  onClick={() => setIsAddModalOpen(false)}
                  className="px-4 py-2 text-xs font-medium text-slate-700 border border-slate-300 rounded-lg hover:bg-slate-50"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 text-xs font-semibold text-white bg-slate-900 rounded-lg hover:bg-slate-800 transition-colors"
                >
                  Create Service
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
