import React, { useState } from 'react';
import { LedgerTransaction, ProductCategory, Order } from '../types';
import { IndianRupee, Printer, ArrowDownRight, ArrowUpRight, Plus, Filter, Calendar } from 'lucide-react';
import { RevenueChart } from './RevenueChart';

interface AdminCashLedgerProps {
  transactions: LedgerTransaction[];
  orders: Order[];
  onAddTransaction: (tx: LedgerTransaction) => void;
}

export const AdminCashLedger: React.FC<AdminCashLedgerProps> = ({
  transactions,
  orders,
  onAddTransaction,
}) => {
  const [verticalFilter, setVerticalFilter] = useState<'all' | ProductCategory>('all');
  const [isRecordModalOpen, setIsRecordModalOpen] = useState(false);

  // New Record Form States
  const [orderId, setOrderId] = useState('ORD-2026-1042');
  const [customerName, setCustomerName] = useState('Ankit Yadav');
  const [category, setCategory] = useState<ProductCategory>('printing');
  const [type, setType] = useState<'advance' | 'balance' | 'refund' | 'direct_payment'>('balance');
  const [amount, setAmount] = useState(498);
  const [paymentMethod, setPaymentMethod] = useState<'UPI / PhonePe' | 'Cash at Counter' | 'Card / POS' | 'Wallet Credit'>('Cash at Counter');
  const [notes, setNotes] = useState('Counter balance payment on delivery');

  const filteredTx = transactions.filter((t) =>
    verticalFilter === 'all' ? true : t.category === verticalFilter
  );

  // Financial aggregates
  const totalRevenue = filteredTx.reduce((sum, t) => {
    if (t.type === 'refund') return sum - t.amount;
    return sum + t.amount;
  }, 0);

  const totalAdvance = filteredTx
    .filter((t) => t.type === 'advance')
    .reduce((sum, t) => sum + t.amount, 0);

  const totalBalance = filteredTx
    .filter((t) => t.type === 'balance')
    .reduce((sum, t) => sum + t.amount, 0);

  const totalRefunds = filteredTx
    .filter((t) => t.type === 'refund')
    .reduce((sum, t) => sum + t.amount, 0);

  const handleCreateTx = (e: React.FormEvent) => {
    e.preventDefault();
    const newTx: LedgerTransaction = {
      id: 'tx_' + Date.now(),
      orderId: orderId.trim(),
      customerName: customerName.trim(),
      category: category,
      type: type,
      amount: Number(amount),
      paymentMethod: paymentMethod,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      notes: notes.trim(),
    };
    onAddTransaction(newTx);
    setIsRecordModalOpen(false);
  };

  const handlePrintLedger = () => {
    window.print();
  };

  return (
    <div className="space-y-6">
      {/* Top Ledger Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-4 rounded-xl border border-slate-200">
        <div>
          <div className="flex items-center gap-2 text-xs text-slate-500 mb-1">
            <span>Accounting Ledger</span>
            <span aria-hidden="true">·</span>
            <span>Daily Cash & UPI Books</span>
            <span aria-hidden="true">·</span>
            <span>Audited Balances</span>
          </div>
          <h2 className="text-base font-bold text-slate-900">
            Cash & Accounting Daily Ledger
          </h2>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handlePrintLedger}
            className="px-3.5 py-2 text-xs font-semibold text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-50 transition-colors flex items-center gap-1.5 cursor-pointer no-print"
          >
            <Printer className="w-4 h-4 text-slate-500" />
            <span>Print Ledger</span>
          </button>
          <button
            onClick={() => setIsRecordModalOpen(true)}
            className="px-4 py-2 text-xs font-semibold text-white bg-slate-900 rounded-lg hover:bg-slate-800 transition-colors flex items-center gap-1.5 cursor-pointer no-print"
          >
            <Plus className="w-4 h-4" />
            <span>Record Cash / Payment</span>
          </button>
        </div>
      </div>

      {/* KPI Financial Metric Strip */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white p-4 rounded-xl border border-slate-200 space-y-1">
          <span className="text-xs text-slate-500 block">Total Net Collection</span>
          <div className="text-2xl font-bold text-slate-900 font-mono-numbers">
            ₹{totalRevenue.toLocaleString()}
          </div>
          <span className="text-[11px] text-emerald-700 font-medium">Daily Counter & Online</span>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 space-y-1">
          <span className="text-xs text-slate-500 block">Total Advance Deposits</span>
          <div className="text-2xl font-bold text-indigo-700 font-mono-numbers">
            ₹{totalAdvance.toLocaleString()}
          </div>
          <span className="text-[11px] text-slate-500">Securing active jobs</span>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 space-y-1">
          <span className="text-xs text-slate-500 block">Balance Cleared at Delivery</span>
          <div className="text-2xl font-bold text-emerald-700 font-mono-numbers">
            ₹{totalBalance.toLocaleString()}
          </div>
          <span className="text-[11px] text-slate-500">Fulfilled collections</span>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 space-y-1">
          <span className="text-xs text-slate-500 block">Cancelled & Refunded</span>
          <div className="text-2xl font-bold text-rose-600 font-mono-numbers">
            ₹{totalRefunds.toLocaleString()}
          </div>
          <span className="text-[11px] text-slate-500">Accidental cancellations</span>
        </div>
      </div>

      {/* Revenue vs Service Analytics Chart using Recharts */}
      <RevenueChart orders={orders} transactions={transactions} />

      {/* Filter Tabs */}
      <div className="flex items-center gap-1.5 bg-slate-100 p-1 rounded-lg w-fit no-print">
        <button
          onClick={() => setVerticalFilter('all')}
          className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors cursor-pointer ${
            verticalFilter === 'all' ? 'bg-white text-slate-900 shadow-xs font-semibold' : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          All Departments ({transactions.length})
        </button>
        <button
          onClick={() => setVerticalFilter('printing')}
          className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors cursor-pointer ${
            verticalFilter === 'printing' ? 'bg-white text-slate-900 shadow-xs font-semibold' : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          Printing Hub
        </button>
        <button
          onClick={() => setVerticalFilter('mobile')}
          className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors cursor-pointer ${
            verticalFilter === 'mobile' ? 'bg-white text-slate-900 shadow-xs font-semibold' : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          Mobile Repairs
        </button>
        <button
          onClick={() => setVerticalFilter('csc')}
          className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors cursor-pointer ${
            verticalFilter === 'csc' ? 'bg-white text-slate-900 shadow-xs font-semibold' : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          CSC Services
        </button>
      </div>

      {/* Ledger Table */}
      <div className="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-2xs">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 text-slate-700 font-semibold border-b border-slate-200">
              <tr>
                <th className="py-3 px-4">Time</th>
                <th className="py-3 px-4">Order ID</th>
                <th className="py-3 px-4">Customer Name</th>
                <th className="py-3 px-4">Department</th>
                <th className="py-3 px-4">Type</th>
                <th className="py-3 px-4">Payment Method</th>
                <th className="py-3 px-4 text-right">Amount (₹)</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 font-mono-numbers">
              {filteredTx.map((tx) => {
                const isRefund = tx.type === 'refund';
                return (
                  <tr key={tx.id} className="hover:bg-slate-50/70 transition-colors">
                    <td className="py-3 px-4 text-slate-500 text-[11px] font-sans">
                      {tx.timestamp}
                    </td>
                    <td className="py-3 px-4 font-bold text-slate-900">
                      {tx.orderId}
                    </td>
                    <td className="py-3 px-4 font-sans text-slate-800">
                      {tx.customerName}
                    </td>
                    <td className="py-3 px-4">
                      <span className="text-[10px] uppercase font-semibold text-slate-600 bg-slate-100 px-2 py-0.5 rounded font-sans">
                        {tx.category}
                      </span>
                    </td>
                    <td className="py-3 px-4 font-sans">
                      <span
                        className={`text-[11px] font-medium capitalize ${
                          tx.type === 'advance'
                            ? 'text-indigo-700'
                            : tx.type === 'balance'
                            ? 'text-emerald-700'
                            : tx.type === 'refund'
                            ? 'text-rose-700'
                            : 'text-slate-700'
                        }`}
                      >
                        {tx.type.replace('_', ' ')}
                      </span>
                    </td>
                    <td className="py-3 px-4 font-sans text-slate-600">
                      {tx.paymentMethod}
                    </td>
                    <td className="py-3 px-4 text-right font-bold text-sm">
                      <span className={isRefund ? 'text-rose-600' : 'text-slate-900'}>
                        {isRefund ? '-' : '+'}₹{tx.amount}
                      </span>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* RECORD TRANSACTION MODAL */}
      {isRecordModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 backdrop-blur-xs p-4 no-print">
          <div className="w-full max-w-md bg-white rounded-xl shadow-2xl border border-slate-200 overflow-hidden">
            <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 bg-slate-50">
              <h3 className="text-base font-bold text-slate-900">Record Counter Transaction</h3>
              <button
                onClick={() => setIsRecordModalOpen(false)}
                className="text-slate-400 hover:text-slate-700 p-1"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleCreateTx} className="p-6 space-y-4 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Related Order ID</label>
                <input
                  type="text"
                  required
                  value={orderId}
                  onChange={(e) => setOrderId(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-slate-900 font-mono-numbers"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Customer Full Name</label>
                <input
                  type="text"
                  required
                  value={customerName}
                  onChange={(e) => setCustomerName(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-slate-900"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Vertical</label>
                  <select
                    value={category}
                    onChange={(e) => setCategory(e.target.value as ProductCategory)}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg bg-white"
                  >
                    <option value="printing">Custom Printing</option>
                    <option value="mobile">Mobile Repair</option>
                    <option value="csc">CSC Services</option>
                  </select>
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Transaction Type</label>
                  <select
                    value={type}
                    onChange={(e) => setType(e.target.value as any)}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg bg-white"
                  >
                    <option value="advance">Advance Deposit</option>
                    <option value="balance">Balance Settlement</option>
                    <option value="direct_payment">Direct Full Payment</option>
                    <option value="refund">Refund Issued</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Amount (₹)</label>
                  <input
                    type="number"
                    min={1}
                    required
                    value={amount}
                    onChange={(e) => setAmount(Number(e.target.value))}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg font-mono-numbers text-sm font-bold"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Payment Channel</label>
                  <select
                    value={paymentMethod}
                    onChange={(e) => setPaymentMethod(e.target.value as any)}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg bg-white"
                  >
                    <option value="Cash at Counter">Cash at Counter</option>
                    <option value="UPI / PhonePe">UPI / PhonePe</option>
                    <option value="Card / POS">Card / POS</option>
                    <option value="Wallet Credit">Wallet Credit</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Internal Reference Notes</label>
                <input
                  type="text"
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg"
                />
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-slate-200">
                <button
                  type="button"
                  onClick={() => setIsRecordModalOpen(false)}
                  className="px-4 py-2 font-medium text-slate-700 border border-slate-300 rounded-lg hover:bg-slate-50"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 font-semibold text-white bg-slate-900 rounded-lg hover:bg-slate-800 transition-colors"
                >
                  Save Entry
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
