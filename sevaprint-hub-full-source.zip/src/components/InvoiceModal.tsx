import React from 'react';
import { Order } from '../types';
import { Printer, X, ShieldCheck, CheckCircle2 } from 'lucide-react';

interface InvoiceModalProps {
  order: Order | null;
  onClose: () => void;
}

export const InvoiceModal: React.FC<InvoiceModalProps> = ({ order, onClose }) => {
  if (!order) return null;

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/70 backdrop-blur-xs p-4 overflow-y-auto">
      <div className="w-full max-w-2xl bg-white rounded-xl shadow-2xl border border-slate-300 overflow-hidden my-8">
        {/* Action bar (hidden on print) */}
        <div className="flex items-center justify-between px-6 py-3 border-b border-slate-200 bg-slate-50 no-print">
          <span className="text-xs font-semibold text-slate-700">Official Cash Memo & Tax Receipt</span>
          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              className="px-3 py-1.5 text-xs font-semibold text-white bg-slate-900 rounded-lg hover:bg-slate-800 transition-colors flex items-center gap-1.5 cursor-pointer"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Print Invoice</span>
            </button>
            <button
              onClick={onClose}
              className="p-1 text-slate-400 hover:text-slate-700 font-bold"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Printable Invoice Container */}
        <div className="p-8 space-y-6 text-slate-900 bg-white">
          {/* Header */}
          <div className="flex justify-between items-start border-b border-slate-300 pb-6">
            <div>
              <h1 className="text-xl font-bold tracking-tight text-slate-900">SevaPrint Hub</h1>
              <p className="text-xs text-slate-600">
                CSC Digital Seva Kendra · Mobile Hardware Diagnostics · Custom Sublimation Studio
              </p>
              <p className="text-[11px] text-slate-500 mt-1">
                GSTIN: 07AAACS1234F1Z5 · UIDAI Agent ID: CSC-UP-8491
              </p>
            </div>
            <div className="text-right">
              <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider block">
                Order Tax Invoice
              </span>
              <span className="font-mono-numbers font-bold text-base text-slate-900 block">
                {order.orderId}
              </span>
              <span className="text-xs text-slate-500 font-mono-numbers">
                Date: {new Date(order.createdAt).toLocaleDateString([], { month: 'short', day: 'numeric', year: 'numeric' })}
              </span>
            </div>
          </div>

          {/* Customer & Department Meta */}
          <div className="grid grid-cols-2 gap-4 text-xs">
            <div>
              <span className="text-slate-500 font-semibold uppercase tracking-wider block text-[10px]">
                Billed To Customer:
              </span>
              <p className="font-bold text-slate-900 text-sm mt-0.5">{order.customerName}</p>
              <p className="text-slate-600 font-mono-numbers">+91 {order.customerPhone}</p>
              <p className="text-slate-600">{order.customerEmail}</p>
            </div>
            <div className="text-right">
              <span className="text-slate-500 font-semibold uppercase tracking-wider block text-[10px]">
                Operational Department:
              </span>
              <p className="font-bold text-slate-900 capitalize text-sm mt-0.5">
                {order.category === 'printing' ? 'Custom Printing Hub' : order.category === 'mobile' ? 'Mobile Repair Lab' : 'CSC Digital Services'}
              </p>
              <p className="text-slate-600">Status: <span className="font-semibold capitalize">{order.orderStatus.replace('_', ' ')}</span></p>
              <p className="text-slate-600">Delivery Target: {order.deliveryDate}</p>
            </div>
          </div>

          {/* Items Table */}
          <table className="w-full text-left text-xs border border-slate-200">
            <thead className="bg-slate-100 text-slate-700 font-semibold">
              <tr>
                <th className="py-2.5 px-3 border-b border-slate-200">Description of Service / Job</th>
                <th className="py-2.5 px-3 border-b border-slate-200 text-center">Qty</th>
                <th className="py-2.5 px-3 border-b border-slate-200 text-right">Unit Price</th>
                <th className="py-2.5 px-3 border-b border-slate-200 text-right">Amount (₹)</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 font-mono-numbers">
              <tr>
                <td className="py-3 px-3 font-sans">
                  <div className="font-bold text-slate-900">{order.productType}</div>
                  {order.customization.text && (
                    <div className="text-[11px] text-slate-600">Text: "{order.customization.text}"</div>
                  )}
                  {order.customization.deviceBrand && (
                    <div className="text-[11px] text-slate-600">
                      Device: {order.customization.deviceBrand} {order.customization.deviceModel}
                    </div>
                  )}
                  {order.customization.cscFormType && (
                    <div className="text-[11px] text-slate-600">
                      Portal File: {order.customization.cscFormType}
                    </div>
                  )}
                </td>
                <td className="py-3 px-3 text-center">{order.quantity}</td>
                <td className="py-3 px-3 text-right">₹{Math.round(order.totalPrice / order.quantity)}</td>
                <td className="py-3 px-3 text-right font-bold text-slate-900">₹{order.totalPrice}</td>
              </tr>
            </tbody>
          </table>

          {/* Payment & Ledger Balance Calculation */}
          <div className="flex justify-between items-start pt-2">
            <div className="max-w-xs space-y-2 text-xs">
              {order.customerDesignApproval.isApproved ? (
                <div className="p-2.5 bg-emerald-50 border border-emerald-200 rounded text-emerald-800 text-[11px]">
                  <div className="flex items-center gap-1 font-bold">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    <span>Customer Design Proof Approved</span>
                  </div>
                  <span className="text-[10px] text-emerald-700 block mt-0.5 font-mono-numbers">
                    Consent Signed: {new Date(order.customerDesignApproval.approvedAt || order.createdAt).toLocaleString()}
                  </span>
                </div>
              ) : (
                <div className="p-2 bg-slate-50 border border-slate-200 rounded text-[10px] text-slate-500">
                  Standard job specifications. Pre-press quality verified.
                </div>
              )}
            </div>

            <div className="w-64 space-y-1.5 text-xs">
              <div className="flex justify-between text-slate-600">
                <span>Subtotal:</span>
                <span className="font-mono-numbers">₹{order.totalPrice}</span>
              </div>
              <div className="flex justify-between text-slate-600">
                <span>Advance Paid:</span>
                <span className="font-mono-numbers text-emerald-700 font-bold">-₹{order.advancePaid}</span>
              </div>
              <div className="flex justify-between border-t border-slate-300 pt-2 text-sm font-bold text-slate-900">
                <span>Balance Payable:</span>
                <span className="font-mono-numbers">₹{order.balanceRemaining}</span>
              </div>
            </div>
          </div>

          {/* Footer & Signature */}
          <div className="pt-8 border-t border-slate-200 flex justify-between items-end text-[11px] text-slate-500">
            <div>
              <p>Thank you for choosing SevaPrint Hub!</p>
              <p>Support: support@sevaprint.local · Helpline: 1800-2026-SEVA</p>
            </div>
            <div className="text-right">
              <div className="h-10 border-b border-slate-400 w-40 mb-1" />
              <span>Authorized Store Signatory</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
