export type ProductCategory = 'printing' | 'mobile' | 'csc';

export type OrderStatus =
  | 'order_received'
  | 'designing'
  | 'awaiting_approval'
  | 'advance_paid'
  | 'printing'
  | 'quality_check'
  | 'packing'
  | 'ready_delivery'
  | 'cancelled';

export interface CustomerDesignApproval {
  isApproved: boolean;
  approvedAt?: string;
  approvedProofUrl?: string;
  legalConsentText?: string;
  customerIp?: string;
  reviewedByCustomerName?: string;
}

export interface OrderCustomization {
  text?: string;
  textColor?: string;
  productColor?: string;
  size?: string;
  printSide?: 'front' | 'back' | 'both';
  deviceBrand?: string;
  deviceModel?: string;
  issueTypes?: string[];
  issueDescription?: string;
  preferredSlot?: string;
  imeiOrSerial?: string;
  cscFormType?: string;
  applicantAadhaarOrId?: string;
  uploadedDocs?: { name: string; size: string; encryptedHash: string; type: string }[];
}

export interface OrderTimelineEvent {
  status: OrderStatus;
  label: string;
  timestamp: string;
  note?: string;
  actor: 'customer' | 'admin' | 'system';
}

export interface Order {
  id: string;
  orderId: string; // e.g. ORD-2026-1042
  customerName: string;
  customerPhone: string;
  customerEmail: string;
  category: ProductCategory;
  serviceId: string;
  productType: string;
  quantity: number;
  customization: OrderCustomization;
  customerDesignFile?: string;
  adminDesignProofUrl?: string;
  totalPrice: number;
  advancePaid: number;
  balanceRemaining: number;
  deliveryDate: string;
  orderStatus: OrderStatus;
  customerDesignApproval: CustomerDesignApproval;
  canCancel: boolean; // strictly active ONLY before order status moves to designing/in-progress
  createdAt: string;
  timeline: OrderTimelineEvent[];
  qualityCheckNotes?: string;
  isQCPassed?: boolean;
  refundStatus?: 'none' | 'initiated' | 'completed';
}

export interface ServiceItem {
  id: string;
  category: ProductCategory;
  title: string;
  description: string;
  basePrice: number;
  turnaroundHours: number;
  isActive: boolean;
  requiredDocs?: string[];
  popularBadge?: string;
  availableColors?: string[];
  availableSizes?: string[];
}

export interface User {
  id: string;
  name: string;
  phone: string;
  email: string;
  role: 'customer' | 'admin';
  walletBalance: number;
}

export interface LedgerTransaction {
  id: string;
  orderId: string;
  category: ProductCategory;
  customerName: string;
  type: 'advance' | 'balance' | 'refund' | 'direct_payment';
  amount: number;
  paymentMethod: 'UPI / PhonePe' | 'Cash at Counter' | 'Card / POS' | 'Wallet Credit';
  timestamp: string;
  notes?: string;
}
